"""Saree ERP server — Python standard library only. No npm, no pip packages.
Run:  python3 app/server.py     then open http://127.0.0.1:8765
Data lives in data/saree.db (never touched by the updater). Localhost only:
this is a single-showroom, owner-controlled app, so there are no logins/roles.
"""
from __future__ import annotations
import json, shutil, sqlite3, sys
from datetime import date, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

sys.path.insert(0, str(Path(__file__).resolve().parent))
import db as dbmod, services as svc, updater

APP_ROOT = Path(__file__).resolve().parent.parent
WEB_DIR = APP_ROOT / "web"
import os
PORT = int(os.environ.get("SAREE_ERP_PORT", "8765"))

def rows(con, sql, args=()):
    return [dict(r) for r in con.execute(sql, args)]

def one(con, sql, args=()):
    r = con.execute(sql, args).fetchone()
    return dict(r) if r else None

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, obj, ctype="application/json"):
        body = obj if isinstance(obj, bytes) else json.dumps(obj, default=str).encode()
        self.send_response(code); self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n).decode() or "{}") if n else {}
    def _con(self): return dbmod.connect()
    def do_GET(self): self._route()
    def do_POST(self): self._route()
    def do_PUT(self): self._route()
    def _route(self):
        u = urlparse(self.path); path = u.path; q = {k: v[0] for k, v in parse_qs(u.query).items()}
        try:
            if path in ("/", "/index.html"):
                return self._send(200, (WEB_DIR / "index.html").read_bytes(), "text/html")
            if path.startswith("/web/") or path in ("/app.js", "/style.css", "/icon.png", "/favicon.png", "/favicon.ico"):
                f = WEB_DIR / path.lstrip("/").replace("web/", "")
                if f.exists():
                    ct = {"js": "text/javascript", "css": "text/css", "png": "image/png", "ico": "image/x-icon", "html": "text/html"}.get(f.suffix.lstrip("."), "application/octet-stream")
                    return self._send(200, f.read_bytes(), ct)
            if not path.startswith("/api/"):
                return self._send(404, {"error": "not found"})
            return self._api(path, q)
        except ValueError as e:
            return self._send(400, {"error": str(e)})
        except Exception as e:
            return self._send(500, {"error": f"{type(e).__name__}: {e}"})

    def _api(self, path, q):
        con = self._con()
        try:
            m = self.command
            # ---- dashboard / settings / update / backup ----
            if path == "/api/dashboard":
                d = q.get("date", date.today().isoformat())
                f, t = {"today": (d, d), "yesterday": ((date.fromisoformat(d)-timedelta(days=1)).isoformat(),)*2,
                        "this_month": (d[:8]+"01", d), "custom": (q.get("from", d), q.get("to", d))}.get(q.get("range", "today"), (d, d))
                return self._send(200, svc.dashboard(con, f, t))
            if path == "/api/settings":
                if m == "GET": return self._send(200, one(con, "SELECT * FROM company_settings WHERE id=1"))
                d = self._body(); allowed = {"showroom_name","address","phone","whatsapp","email","website","gstin","pan","state","pincode","tagline","invoice_prefix","default_gst_mode","default_payment","auto_update_mode","update_channel_url","low_stock_threshold","drive_backup_folder","drive_auto_backup"}
                if "drive_auto_backup" in d: d["drive_auto_backup"] = 1 if d["drive_auto_backup"] in (True, 1, "1", "true") else 0
                sets = ", ".join(f"{k}=?" for k in d if k in allowed); vals = [d[k] for k in d if k in allowed]
                if sets: con.execute(f"UPDATE company_settings SET {sets} WHERE id=1", vals); con.commit()
                return self._send(200, {"ok": True})
            if path == "/api/version":
                return self._send(200, {"version": updater.current_version()})
            if path == "/api/update/check":
                s = one(con, "SELECT auto_update_mode, update_channel_url FROM company_settings WHERE id=1")
                if not s["update_channel_url"]: return self._send(200, {"current": updater.current_version(), "available": False, "note": "No update channel set in Settings."})
                return self._send(200, updater.check(s["update_channel_url"], s["auto_update_mode"]))
            if path == "/api/backup" and m == "POST":
                s = one(con, "SELECT drive_backup_folder, drive_auto_backup FROM company_settings WHERE id=1")
                con.close()
                dest = svc.make_backup(dbmod.DB_PATH, dbmod.BACKUP_DIR)
                con = self._con()
                con.execute("INSERT INTO backup_records (filename, size_bytes) VALUES (?,?)", (dest.name, dest.stat().st_size)); con.commit()
                out = {"ok": True, "file": dest.name, "local_path": str(dest)}
                if s and s["drive_auto_backup"] and s["drive_backup_folder"]:
                    try:
                        ddest = svc.copy_backup_to_drive(dest, s["drive_backup_folder"])
                        out["drive_file"] = str(ddest)
                    except Exception as e:
                        out["drive_warning"] = str(e)
                return self._send(200, out)
            if path == "/api/backup/drive" and m == "POST":
                s = one(con, "SELECT drive_backup_folder FROM company_settings WHERE id=1")
                if not (s and s["drive_backup_folder"]):
                    raise ValueError("No Google Drive folder set. Go to Settings, install Google Drive for Desktop, sign in with your Gmail, and set the backup folder there first.")
                con.close()
                dest = svc.make_backup(dbmod.DB_PATH, dbmod.BACKUP_DIR)
                ddest = svc.copy_backup_to_drive(dest, s["drive_backup_folder"])
                con = self._con()
                con.execute("INSERT INTO backup_records (filename, size_bytes) VALUES (?,?)", (dest.name, dest.stat().st_size)); con.commit()
                return self._send(200, {"ok": True, "file": dest.name, "drive_file": str(ddest),
                    "note": "Copied to your Google Drive folder. Google Drive for Desktop syncs it to your Gmail Drive account, so the backup survives even if this laptop is damaged."})
            if path == "/api/backups" and m == "GET":
                local = []
                for d in (dbmod.BACKUP_DIR, APP_ROOT / "backups"):
                    if d.exists():
                        for f in sorted(d.glob("*.db"), reverse=True):
                            local.append({"file": f.name, "source": "local", "size": f.stat().st_size})
                s = one(con, "SELECT drive_backup_folder FROM company_settings WHERE id=1")
                drive = []
                if s and s["drive_backup_folder"]:
                    from pathlib import Path as _P
                    _d = _P(s["drive_backup_folder"])
                    if _d.is_dir():
                        drive = [{"file": f.name, "source": "drive", "size": f.stat().st_size} for f in sorted(_d.glob("*.db"), reverse=True)]
                seen = set(); merged = []
                for r in local + drive:
                    if r["file"] not in seen: seen.add(r["file"]); merged.append(r)
                return self._send(200, {"local": local, "drive": drive, "all": merged, "drive_folder": (s["drive_backup_folder"] if s else "")})
            if path == "/api/restore/prepare" and m == "POST":
                d = self._body(); fname = d.get("filename", ""); source = d.get("source", "local")
                if not fname or "/" in fname or "\\" in fname: raise ValueError("Choose a backup file to restore")
                if source == "drive":
                    s = one(con, "SELECT drive_backup_folder FROM company_settings WHERE id=1")
                    if not (s and s["drive_backup_folder"]): raise ValueError("No Google Drive folder set")
                    from pathlib import Path as _P
                    src = _P(s["drive_backup_folder"]) / fname
                else:
                    src = dbmod.BACKUP_DIR / fname
                    if not src.exists(): src = APP_ROOT / "backups" / fname
                if not src.exists(): raise ValueError(f"Backup file not found: {fname}")
                con.close()
                shutil.copyfile(str(src), str(APP_ROOT / "pending_restore.db"))
                return self._send(200, {"ok": True, "file": fname, "restart_required": True,
                    "note": "Restore is staged. Close and reopen the app (Electron or Saree-ERP.bat) and it will replace the database with this backup, after first saving a pre-restore copy of the current database."})
            # ---- reference data ----
            if path == "/api/categories": return self._send(200, rows(con, "SELECT * FROM categories ORDER BY name"))
            if path == "/api/label-templates":
                if m == "GET": return self._send(200, rows(con, "SELECT * FROM label_templates ORDER BY width_mm, height_mm"))
                d = self._body()
                if not d.get("name") or not d.get("width_mm") or not d.get("height_mm"): raise ValueError("Tag template needs a name, width (mm) and height (mm)")
                cur = con.execute("INSERT INTO label_templates (name,width_mm,height_mm,fields_json,layout,primary_colour,show_border,font_scale) VALUES (?,?,?,?,?,?,?,?)",
                    (d["name"], float(d["width_mm"]), float(d["height_mm"]), json.dumps(d.get("fields", ["showroom","product","selling_price","barcode"])),
                     d.get("layout","standard"), d.get("primary_colour","#111111"), 1 if d.get("show_border", True) else 0, float(d.get("font_scale", 1.0))))
                con.commit(); return self._send(200, {"ok": True, "id": cur.lastrowid})
            if path == "/api/labels":
                tpl = int(q.get("template_id", 0)); ids = [int(x) for x in q.get("unit_ids","").split(",") if x.strip()]
                return self._send(200, svc.label_data(con, tpl, ids))
            if path == "/api/suppliers":
                if m == "GET": return self._send(200, [{**r, "balance": svc.supplier_balance(con, r["id"])} for r in rows(con, "SELECT * FROM suppliers ORDER BY name")])
                d = self._body()
                if not d.get("name"): raise ValueError("Supplier name required")
                cur = con.execute("INSERT INTO suppliers (name,contact_person,mobile,whatsapp,email,address,gstin,state,opening_balance,credit_limit,payment_terms,notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                    (d["name"], d.get("contact_person",""), d.get("mobile",""), d.get("whatsapp",""), d.get("email",""), d.get("address",""), d.get("gstin",""), d.get("state",""), svc.r2(d.get("opening_balance",0)), svc.r2(d.get("credit_limit",0)), d.get("payment_terms",""), d.get("notes","")))
                con.commit(); return self._send(200, {"ok": True, "id": cur.lastrowid})
            if path == "/api/customers":
                if m == "GET": return self._send(200, [{**r, "balance": svc.customer_balance(con, r["id"]), "advance": svc.advance_balance(con, r["id"])} for r in rows(con, "SELECT * FROM customers ORDER BY name")])
                d = self._body()
                cid = svc.create_customer(con, d); con.commit(); return self._send(200, {"ok": True, "id": cid})
            if path == "/api/employees":
                if m == "GET": return self._send(200, rows(con, "SELECT * FROM employees ORDER BY name"))
                d = self._body(); cur = con.execute("INSERT INTO employees (name,mobile,address,joining_date,salary,designation,department) VALUES (?,?,?,?,?,?,?)",
                    (d.get("name",""), d.get("mobile",""), d.get("address",""), d.get("joining_date",""), svc.r2(d.get("salary",0)), d.get("designation","Salesperson"), d.get("department","Sales")))
                con.commit(); return self._send(200, {"ok": True, "id": cur.lastrowid})
            # ---- products / inventory ----
            if path == "/api/products":
                if m == "GET":
                    cond, args = ["1=1"], []
                    if q.get("search"): cond.append("(p.name LIKE ? OR p.sku LIKE ? OR p.saree_code LIKE ?)"); args += [f"%{q['search']}%"]*3
                    if q.get("category_id"): cond.append("p.category_id=?"); args.append(q["category_id"])
                    if q.get("colour"): cond.append("p.colour LIKE ?"); args.append(f"%{q['colour']}%")
                    if q.get("fabric"): cond.append("p.fabric LIKE ?"); args.append(f"%{q['fabric']}%")
                    if q.get("min_price"): cond.append("p.selling_price>=?"); args.append(q["min_price"])
                    if q.get("max_price"): cond.append("p.selling_price<=?"); args.append(q["max_price"])
                    if q.get("status"): cond.append("p.status=?"); args.append(q["status"])
                    return self._send(200, rows(con, f"SELECT p.*, c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE {' AND '.join(cond)} ORDER BY p.id DESC LIMIT 500", args))
                d = self._body()
                if not d.get("name"): raise ValueError("Product name required")
                cur = con.execute("INSERT INTO products (name,saree_code,sku,category_id,subcategory,brand,supplier_id,fabric,saree_type,collection,design_name,design_number,colour,secondary_colour,pattern,border_type,work_type,occasion,style,length,width,weight,blouse_details,purchase_price,mrp,selling_price,wholesale_price,min_selling_price,gst_rate,hsn,rack,shelf,location,description,opening_stock,current_stock,min_stock_alert,product_type,size) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (d["name"], d.get("saree_code",""), d.get("sku") or None, d.get("category_id"), d.get("subcategory",""), d.get("brand",""), d.get("supplier_id"), d.get("fabric",""), d.get("saree_type",""), d.get("collection",""), d.get("design_name",""), d.get("design_number",""), d.get("colour",""), d.get("secondary_colour",""), d.get("pattern",""), d.get("border_type",""), d.get("work_type",""), d.get("occasion",""), d.get("style",""), d.get("length",""), d.get("width",""), svc.r2(d.get("weight",0)), d.get("blouse_details",""), svc.r2(d.get("purchase_price",0)), svc.r2(d.get("mrp",0)), svc.r2(d.get("selling_price",0)), svc.r2(d.get("wholesale_price",0)), svc.r2(d.get("min_selling_price",0)), float(d.get("gst_rate",5)), d.get("hsn","6308"), d.get("rack",""), d.get("shelf",""), d.get("location",""), d.get("description",""), int(d.get("opening_stock",0)), 0, int(d.get("min_stock_alert",2)), d.get("product_type","Saree"), d.get("size","")))
                pid = cur.lastrowid
                # current_stock starts at 0 above because add_units() itself adds
                # qty to current_stock — setting it to opening_stock here double-counted stock.
                if d.get("opening_stock"): svc.add_units(con, pid, int(d["opening_stock"]))
                con.commit(); return self._send(200, {"ok": True, "id": pid})
            if path == "/api/units":
                if q.get("barcode"):
                    u = one(con, "SELECT u.*, p.name product, p.selling_price, p.mrp FROM product_units u JOIN products p ON p.id=u.product_id WHERE u.barcode=?", (q["barcode"],))
                    return self._send(200, u or {"error": "barcode not found"})
                _cond, _args = ["(?='' OR u.status=?)"], [q.get("status",""), q.get("status","")]
                if q.get("product_id"): _cond.append("u.product_id=?"); _args.append(q["product_id"])
                return self._send(200, rows(con, f"SELECT u.*, p.name product FROM product_units u JOIN products p ON p.id=u.product_id WHERE {' AND '.join(_cond)} ORDER BY u.id DESC LIMIT 500", _args))
            if path == "/api/add-stock" and m == "POST":
                # Quick Add Stock: top up an existing saree with barcoded pieces.
                # Stock-only — deliberately NO supplier, invoice, payment or journal:
                # use New Purchase when a supplier bill must be recorded.
                d = self._body(); prod = one(con, "SELECT * FROM products WHERE id=?", (d["product_id"],))
                if not prod: raise ValueError("Saree not found")
                qty = int(d.get("qty", 0))
                if qty < 1: raise ValueError("Quantity must be at least 1 piece")
                rate = d.get("purchase_price")
                barcodes = svc.add_units(con, prod["id"], qty, price=(float(rate) if rate not in (None, "") else None))
                svc._audit(con, "stock", "quick_add", {"stock": prod["current_stock"]}, {"added": qty, "product_id": prod["id"]}); con.commit()
                new_stock = one(con, "SELECT current_stock FROM products WHERE id=?", (prod["id"],))["current_stock"]
                return self._send(200, {"ok": True, "product": prod["name"], "qty_added": qty, "new_stock": new_stock, "barcodes": barcodes})
            if path == "/api/stock-recount" and m == "POST":
                # Repair for the old double-count bug (5 pieces entered showed 10):
                # set current_stock to the actual count of Available barcoded pieces.
                # Explicit, user-triggered only — it overwrites manual stock adjustments,
                # so it never runs automatically on startup.
                d = self._body()
                if d.get("product_id"):
                    _p = one(con, "SELECT * FROM products WHERE id=?", (d["product_id"],))
                    prods = [_p] if _p else []
                else:
                    prods = rows(con, "SELECT * FROM products ORDER BY id")
                changed = []
                for prod in prods:
                    avail = one(con, "SELECT COUNT(*) c FROM product_units WHERE product_id=? AND status='Available'", (prod["id"],))["c"]
                    if avail != prod["current_stock"]:
                        svc._audit(con, "stock", "recount", {"stock": prod["current_stock"]}, {"stock": avail, "product_id": prod["id"]})
                        con.execute("UPDATE products SET current_stock=? WHERE id=?", (avail, prod["id"]))
                        changed.append({"id": prod["id"], "name": prod["name"], "before": prod["current_stock"], "after": avail})
                con.commit()
                return self._send(200, {"ok": True, "changed": changed, "checked": len(prods)})
            if path == "/api/stock-adjust" and m == "POST":
                d = self._body(); prod = one(con, "SELECT * FROM products WHERE id=?", (d["product_id"],))
                if not prod: raise ValueError("Product not found")
                if not d.get("reason"): raise ValueError("Adjustment reason is mandatory")
                diff = int(d["physical_qty"]) - prod["current_stock"]
                con.execute("INSERT INTO stock_adjustments (product_id, system_qty, physical_qty, diff, reason) VALUES (?,?,?,?,?)", (d["product_id"], prod["current_stock"], d["physical_qty"], diff, d["reason"]))
                con.execute("UPDATE products SET current_stock=? WHERE id=?", (int(d["physical_qty"]), d["product_id"]))
                con.execute("INSERT INTO stock_movements (product_id, movement_type, qty, reason) VALUES (?,?,?,?)", (d["product_id"], "ADJUST", diff, d["reason"]))
                svc._audit(con, "stock", "adjust", {"system": prod["current_stock"]}, {"physical": d["physical_qty"], "reason": d["reason"]}); con.commit()
                return self._send(200, {"ok": True, "diff": diff})
            if path == "/api/purchase-returns" and m == "POST":
                d = self._body(); amt = svc.purchase_return(con, d["purchase_id"], reason=d.get("reason",""), unit_id=d.get("unit_id"), product_id=d.get("product_id"), qty=int(d.get("qty",1))); con.commit()
                return self._send(200, {"ok": True, "amount_returned": amt})
            if path == "/api/supplier-payments" and m == "POST":
                d = self._body(); svc.supplier_payment(con, d["supplier_id"], float(d["amount"]), d.get("mode","Cash"), purchase_id=d.get("purchase_id"), notes=d.get("notes","")); con.commit()
                return self._send(200, {"ok": True, "balance": svc.supplier_balance(con, d["supplier_id"])})
            if path == "/api/supplier-ledger":
                if not q.get("supplier_id"): raise ValueError("supplier_id required")
                return self._send(200, svc.supplier_ledger(con, int(q["supplier_id"])))
            if path == "/api/stock-movements":
                cond, args = ["1=1"], []
                if q.get("product_id"): cond.append("sm.product_id=?"); args.append(q["product_id"])
                return self._send(200, rows(con, f"SELECT sm.*, p.name product FROM stock_movements sm LEFT JOIN products p ON p.id=sm.product_id WHERE {' AND '.join(cond)} ORDER BY sm.id DESC LIMIT 500", args))
            # ---- transactions ----
            if path == "/api/purchases":
                if m == "GET":
                    if q.get("id"):
                        inv = one(con, "SELECT pi.*, s.name supplier, s.mobile supplier_mobile, s.gstin supplier_gstin FROM purchase_invoices pi LEFT JOIN suppliers s ON s.id=pi.supplier_id WHERE pi.id=?", (q["id"],))
                        if not inv: return self._send(404, {"error": "purchase invoice not found"})
                        items = rows(con, "SELECT pi_item.*, p.name product_name, p.sku FROM purchase_items pi_item LEFT JOIN products p ON p.id=pi_item.product_id WHERE pi_item.purchase_id=?", (q["id"],))
                        payments = rows(con, "SELECT * FROM purchase_payments WHERE purchase_id=?", (q["id"],))
                        return self._send(200, {**inv, "items": items, "payments": payments})
                    return self._send(200, rows(con, "SELECT pi.*, s.name supplier FROM purchase_invoices pi LEFT JOIN suppliers s ON s.id=pi.supplier_id ORDER BY pi.id DESC LIMIT 200"))
                pid = svc.create_purchase(con, self._body()); con.commit()
                return self._send(200, {"ok": True, "id": pid, "purchase_no": one(con, "SELECT purchase_no FROM purchase_invoices WHERE id=?", (pid,))["purchase_no"]})
            if path == "/api/sales":
                if m == "GET":
                    if q.get("id"):
                        inv = one(con, "SELECT si.*, c.name customer, c.mobile customer_mobile, c.address customer_address, c.gstin customer_gstin FROM sales_invoices si LEFT JOIN customers c ON c.id=si.customer_id WHERE si.id=?", (q["id"],))
                        if not inv: return self._send(404, {"error": "invoice not found"})
                        items = rows(con, "SELECT si.*, p.name product_name, p.hsn FROM sales_items si LEFT JOIN products p ON p.id=si.product_id WHERE si.sales_id=?", (q["id"],))
                        payments = rows(con, "SELECT * FROM sales_payments WHERE sales_id=?", (q["id"],))
                        return self._send(200, {**inv, "items": items, "payments": payments})
                    return self._send(200, rows(con, "SELECT si.*, c.name customer FROM sales_invoices si LEFT JOIN customers c ON c.id=si.customer_id ORDER BY si.id DESC LIMIT 200"))
                d = self._body()
                for it in d.get("items", []):
                    if it.get("barcode") and not it.get("unit_id"):
                        u = one(con, "SELECT id FROM product_units WHERE barcode=?", (it["barcode"],))
                        if not u: raise ValueError(f"Barcode {it['barcode']} not found")
                        it["unit_id"] = u["id"]
                sid = svc.create_sale(con, d); con.commit()
                return self._send(200, {"ok": True, "id": sid, "invoice_no": one(con, "SELECT invoice_no FROM sales_invoices WHERE id=?", (sid,))["invoice_no"]})
            if path == "/api/collections" and m == "POST":
                d = self._body(); rec = svc.collect_udhar(con, d["customer_id"], float(d["amount"]), d.get("mode","Cash"), d.get("notes","")); con.commit()
                return self._send(200, {"ok": True, "receipt": rec})
            if path == "/api/advances":
                if m == "GET":
                    cid = q.get("customer_id")
                    sql = "SELECT * FROM customer_advances" + (" WHERE customer_id=?" if cid else "") + " ORDER BY id DESC"
                    return self._send(200, rows(con, sql, (cid,) if cid else ()))
                d = self._body(); aid = svc.receive_advance(con, d["customer_id"], float(d["amount"]), d.get("mode","Cash"), d.get("notes","")); con.commit()
                return self._send(200, {"ok": True, "id": aid})
            if path == "/api/returns" and m == "POST":
                d = self._body(); note = svc.sales_return(con, d["sales_id"], d["unit_id"], d.get("condition","Saleable"), d.get("refund_mode","Credit"), d.get("reason","")); con.commit()
                return self._send(200, {"ok": True, "credit_note": note})
            if path == "/api/expenses":
                if m == "GET": return self._send(200, rows(con, "SELECT * FROM expenses ORDER BY exp_date DESC LIMIT 200"))
                d = self._body(); cur = con.execute("INSERT INTO expenses (exp_date, category, amount, mode, description) VALUES (?,?,?,?,?)", (d.get("exp_date", date.today().isoformat()), d.get("category","Miscellaneous"), svc.r2(d["amount"]), d.get("mode","Cash"), d.get("description","")))
                con.execute("INSERT INTO cash_transactions (txn_type, amount, mode, particulars) VALUES ('OUT',?,?,?)", (svc.r2(d["amount"]), d.get("mode","Cash"), d.get("description",""))) if d.get("mode","Cash")=="Cash" else None
                con.commit(); return self._send(200, {"ok": True, "id": cur.lastrowid})
            if path == "/api/ledger":
                cid = q.get("customer_id")
                if not cid: raise ValueError("customer_id required")
                led = rows(con, "SELECT * FROM customer_ledger WHERE customer_id=? ORDER BY id", (cid,))
                bal = 0.0
                for r in led: bal = svc.r2(bal + r["debit"] - r["credit"]); r["running"] = bal
                cust = one(con, "SELECT opening_balance FROM customers WHERE id=?", (cid,))
                return self._send(200, {"opening": cust["opening_balance"] if cust else 0, "balance": svc.customer_balance(con, cid), "rows": led})
            if path == "/api/ageing": return self._send(200, svc.ageing(con, int(q["customer_id"]) if q.get("customer_id") else None))
            if path == "/api/daybook":
                d = q.get("date", date.today().isoformat())
                return self._send(200, {"cash": rows(con, "SELECT * FROM cash_transactions WHERE txn_date=? ORDER BY id", (d,)),
                                        "bank": rows(con, "SELECT * FROM bank_transactions WHERE txn_date=? ORDER BY id", (d,)),
                                        "journal": rows(con, "SELECT * FROM journal_entries WHERE entry_date=? ORDER BY id", (d,))})
            if path == "/api/audit": return self._send(200, rows(con, "SELECT * FROM audit_logs ORDER BY id DESC LIMIT 200"))
            return self._send(404, {"error": "unknown api"})
        finally:
            con.close()

def apply_pending_restore():
    """Apply a staged restore BEFORE any DB connection: current DB is saved first."""
    pending = APP_ROOT / "pending_restore.db"
    if not pending.exists(): return None
    import datetime
    dbmod.BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    if dbmod.DB_PATH.exists():
        pre = dbmod.BACKUP_DIR / f"pre-restore-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}.db"
        shutil.copyfile(dbmod.DB_PATH, pre)
        print(f"Restore: current database saved as {pre}")
    shutil.copyfile(pending, dbmod.DB_PATH)
    pending.unlink()
    print("Restore applied from staged backup.")
    return True

def main():
    apply_pending_restore()
    dbmod.init_db()
    installed = updater.apply_pending()
    if installed: print(f"Auto-update installed: v{installed} (code backup in backups/)")
    # Background auto-update check (install-on-restart mode only downloads; it never restarts mid-session)
    try:
        con = dbmod.connect(); s = one(con, "SELECT auto_update_mode, update_channel_url FROM company_settings WHERE id=1"); con.close()
        if s and s["update_channel_url"] and s["auto_update_mode"] == "install_on_restart":
            info = updater.check(s["update_channel_url"], "install_on_restart")
            print(f"Update check: current {info['current']}, latest {info['latest']}, available={info['available']}, staged={info.get('staged_for_restart')}")
    except Exception as e:
        print(f"Update check skipped: {e}")
    print(f"Saree ERP running at http://127.0.0.1:{PORT}  (DB: {dbmod.DB_PATH})")
    ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()

if __name__ == "__main__":
    main()

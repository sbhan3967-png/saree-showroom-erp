"""Business logic — every money/stock change goes through here, in one transaction.
No handler in server.py may write sales/purchases/ledger/journal directly.
"""
from __future__ import annotations
import json, sqlite3
from datetime import date

def r2(x): return round(float(x) + 1e-9, 2)

def gst_split(taxable, rate, intra_state):
    gst = r2(taxable * rate / 100)
    if intra_state:
        half = r2(gst / 2)
        return half, gst - half, 0.0
    return 0.0, 0.0, gst

def line_calc(price, qty, discount, rate, mode, intra_state):
    """Returns dict(taxable, cgst, sgst, igst, amount). price is per-piece selling/purchase rate."""
    gross = r2(price * qty - discount)
    if mode == "inclusive":
        taxable = r2(gross / (1 + rate / 100)) if rate else gross
        gst = r2(gross - taxable)
        cg, sg, ig = (r2(gst/2), gst - r2(gst/2), 0.0) if intra_state else (0.0, 0.0, gst)
    else:
        taxable = gross
        cg, sg, ig = gst_split(taxable, rate, intra_state)
    return {"taxable": taxable, "cgst": cg, "sgst": sg, "igst": ig, "amount": r2(taxable + cg + sg + ig)}

def _settings(con):
    return dict(con.execute("SELECT * FROM company_settings WHERE id=1").fetchone())

def _next_no(con, table, col, prefix):
    n = con.execute(f"SELECT COUNT(*) c FROM {table}").fetchone()["c"] + 1
    while True:
        no = f"{prefix}-{n:04d}"
        if not con.execute(f"SELECT 1 FROM {table} WHERE {col}=?", (no,)).fetchone():
            return no
        n += 1

def _audit(con, module, action, old, new):
    con.execute("INSERT INTO audit_logs (module, action, old_values, new_values) VALUES (?,?,?,?)",
                (module, action, json.dumps(old, default=str), json.dumps(new, default=str)))

def _journal(con, voucher, narration, ref_type, ref_id, lines):
    """lines: [(account, debit, credit)]. Must balance, else the whole txn rolls back."""
    d, c = r2(sum(x[1] for x in lines)), r2(sum(x[2] for x in lines))
    if abs(d - c) > 0.02:
        raise ValueError(f"Unbalanced journal {voucher}: debits {d} != credits {c}")
    cur = con.execute("INSERT INTO journal_entries (voucher, narration, ref_type, ref_id) VALUES (?,?,?,?)",
                      (voucher, narration, ref_type, ref_id))
    eid = cur.lastrowid
    for acc, dr, cr in lines:
        if dr or cr:
            con.execute("INSERT INTO journal_lines (entry_id, account, debit, credit) VALUES (?,?,?,?)", (eid, acc, r2(dr), r2(cr)))
    return eid

def _ledger(con, cust_id, voucher, invoice_no, particulars, debit, credit, ref_type, ref_id):
    con.execute("INSERT INTO customer_ledger (customer_id, voucher, invoice_no, particulars, debit, credit, ref_type, ref_id) VALUES (?,?,?,?,?,?,?,?)",
                (cust_id, voucher, invoice_no, particulars, r2(debit), r2(credit), ref_type, ref_id))

def _cash_bank(con, mode, amount, txn_type, particulars, ref_type, ref_id):
    if mode == "Cash":
        con.execute("INSERT INTO cash_transactions (txn_type, amount, mode, particulars, ref_type, ref_id) VALUES (?,?,?,?,?,?)",
                    (txn_type, r2(amount), mode, particulars, ref_type, ref_id))
    elif mode in ("UPI", "Card", "Bank Transfer", "Cheque"):
        con.execute("INSERT INTO bank_transactions (txn_type, amount, mode, particulars, ref_type, ref_id) VALUES (?,?,?,?,?,?)",
                    (txn_type, r2(amount), mode, particulars, ref_type, ref_id))

def customer_balance(con, cust_id):
    r = con.execute("SELECT COALESCE(SUM(debit),0)-COALESCE(SUM(credit),0) b FROM customer_ledger WHERE customer_id=?", (cust_id,)).fetchone()
    cust = con.execute("SELECT opening_balance FROM customers WHERE id=?", (cust_id,)).fetchone()
    return r2((r["b"] if r else 0) + (cust["opening_balance"] if cust else 0))

def advance_balance(con, cust_id):
    r = con.execute("SELECT COALESCE(SUM(balance),0) b FROM customer_advances WHERE customer_id=? AND status!='Closed'", (cust_id,)).fetchone()
    return r2(r["b"] if r else 0)

def supplier_balance(con, sup_id):
    r = con.execute("SELECT COALESCE(SUM(grand_total),0) g FROM purchase_invoices WHERE supplier_id=? AND status='Posted'", (sup_id,)).fetchone()
    p = con.execute("SELECT COALESCE(SUM(amount),0) s FROM purchase_payments WHERE supplier_id=?", (sup_id,)).fetchone()
    ret = con.execute("SELECT COALESCE(SUM(amount),0) s FROM purchase_returns pr JOIN purchase_invoices pi ON pi.id=pr.purchase_id WHERE pi.supplier_id=?", (sup_id,)).fetchone()
    sup = con.execute("SELECT opening_balance FROM suppliers WHERE id=?", (sup_id,)).fetchone()
    return r2((r["g"] if r else 0) - (p["s"] if p else 0) - (ret["s"] if ret else 0) + (sup["opening_balance"] if sup else 0))

def _intra(con, cust_state):
    s = _settings(con)
    return (not cust_state) or cust_state.strip().lower() == s["state"].strip().lower()

def create_customer(con, data):
    if con.execute("SELECT 1 FROM customers WHERE mobile=?", (data["mobile"],)).fetchone():
        raise ValueError("Customer with this mobile already exists — use the existing customer instead of creating a duplicate.")
    cur = con.execute("INSERT INTO customers (name,mobile,alt_mobile,whatsapp,email,address,city,state,pincode,gstin,category,cust_type,opening_balance,credit_limit,credit_period_days,notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (data.get("name",""), data["mobile"], data.get("alt_mobile",""), data.get("whatsapp",""), data.get("email",""),
         data.get("address",""), data.get("city",""), data.get("state",""), data.get("pincode",""), data.get("gstin",""),
         data.get("category","Regular"), data.get("cust_type","Retail"), r2(data.get("opening_balance",0)),
         r2(data.get("credit_limit",0)), int(data.get("credit_period_days",30)), data.get("notes","")))
    cid = cur.lastrowid
    if data.get("opening_balance"):
        _ledger(con, cid, "OPEN", "", "Opening balance", data["opening_balance"], 0, "customer", cid)
    _audit(con, "customers", "create", {}, data)
    return cid

def add_units(con, product_id, qty, purchase_id=None, price=None):
    """Create qty individual barcoded units. Returns list of barcodes."""
    prod = con.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
    if not prod: raise ValueError("Product not found")
    prefix = con.execute("SELECT prefix FROM barcode_settings WHERE id=1").fetchone()["prefix"]
    out = []
    for _ in range(int(qty)):
        n = con.execute("SELECT COUNT(*) c FROM product_units WHERE product_id=?", (product_id,)).fetchone()["c"] + 1
        while True:
            bc = f"{prefix}{product_id:04d}{n:05d}"
            if not con.execute("SELECT 1 FROM product_units WHERE barcode=?", (bc,)).fetchone(): break
            n += 1
        con.execute("INSERT INTO product_units (product_id, barcode, purchase_invoice_id, purchase_price) VALUES (?,?,?,?)",
                    (product_id, bc, purchase_id, r2(price if price is not None else prod["purchase_price"])))
        uid = con.execute("SELECT id FROM product_units WHERE barcode=?", (bc,)).fetchone()["id"]
        con.execute("INSERT INTO stock_movements (product_id, unit_id, barcode, movement_type, qty, ref_type, ref_id) VALUES (?,?,?,?,?,?,?)",
                    (product_id, uid, bc, "IN", 1, "purchase" if purchase_id else "opening", purchase_id or 0))
        out.append(bc)
    con.execute("UPDATE products SET current_stock=current_stock+? WHERE id=?", (int(qty), product_id))
    return out

def create_purchase(con, data):
    """data: supplier_id, supplier_invoice_no, items[{product_id, qty, rate, discount, gst_rate}], payments[{mode,amount}], charges..."""
    s = _settings(con)
    sup = con.execute("SELECT * FROM suppliers WHERE id=?", (data["supplier_id"],)).fetchone()
    if not sup: raise ValueError("Supplier not found")
    if data.get("request_id") and con.execute("SELECT id FROM purchase_invoices WHERE request_id=?", (data["request_id"],)).fetchone():
        return con.execute("SELECT id FROM purchase_invoices WHERE request_id=?", (data["request_id"],)).fetchone()["id"]
    intra = _intra(con, sup["state"])
    mode = data.get("gst_mode", s["default_gst_mode"])
    sub = tax = cg = sg = ig = disc = 0.0
    lines = []
    for it in data["items"]:
        prod = con.execute("SELECT * FROM products WHERE id=?", (it["product_id"],)).fetchone()
        if not prod: raise ValueError("Product in purchase not found")
        lc = line_calc(it["rate"], it["qty"], it.get("discount", 0), it.get("gst_rate", prod["gst_rate"]), mode, intra)
        lines.append((it, lc)); sub += it["rate"]*it["qty"]; disc += it.get("discount", 0)
        tax += lc["taxable"]; cg += lc["cgst"]; sg += lc["sgst"]; ig += lc["igst"]
    charges = r2(data.get("transport", 0) + data.get("packaging", 0) + data.get("other_charges", 0))
    grand = r2(tax + cg + sg + ig + charges)
    paid = r2(sum(p["amount"] for p in data.get("payments", [])))
    if paid > grand + 0.01: raise ValueError("Purchase payment exceeds grand total")
    no = _next_no(con, "purchase_invoices", "purchase_no", "PUR")
    cur = con.execute("INSERT INTO purchase_invoices (purchase_no, supplier_invoice_no, supplier_id, purchase_date, due_date, subtotal, discount, taxable, cgst, sgst, igst, transport, packaging, other_charges, grand_total, paid, outstanding, payment_mode, notes, request_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (no, data.get("supplier_invoice_no",""), data["supplier_id"], data.get("purchase_date", date.today().isoformat()),
         data.get("due_date",""), r2(sub), r2(disc), r2(tax), r2(cg), r2(sg), r2(ig),
         r2(data.get("transport",0)), r2(data.get("packaging",0)), r2(data.get("other_charges",0)),
         grand, paid, r2(grand-paid), ",".join(p["mode"] for p in data.get("payments",[])), data.get("notes",""), data.get("request_id")))
    pid = cur.lastrowid
    for it, lc in lines:
        con.execute("INSERT INTO purchase_items (purchase_id, product_id, qty, rate, discount, taxable, gst_rate, cgst, sgst, igst, amount) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (pid, it["product_id"], it["qty"], it["rate"], it.get("discount",0), lc["taxable"], it.get("gst_rate",5), lc["cgst"], lc["sgst"], lc["igst"], lc["amount"]))
        add_units(con, it["product_id"], it["qty"], purchase_id=pid, price=it["rate"])
    for p in data.get("payments", []):
        con.execute("INSERT INTO purchase_payments (purchase_id, supplier_id, amount, mode) VALUES (?,?,?,?)", (pid, data["supplier_id"], r2(p["amount"]), p["mode"]))
        _cash_bank(con, p["mode"], -p["amount"] if False else p["amount"], "OUT", f"Supplier payment {no}", "purchase", pid)
    # Clean double-entry: purchase itself is Dr Purchases+GST / Cr Payables (full grand).
    # A payment is a separate entry: Dr Payables / Cr Cash-Bank. Both always balance.
    _journal(con, no, f"Purchase {no}", "purchase", pid, [
        ("Purchases", r2(tax + charges), 0), ("GST Input", r2(cg + sg + ig), 0),
        ("Supplier Payables", 0, grand)])
    if paid:
        _journal(con, no + "-PAY", f"Supplier payment {no}", "purchase_payment", pid,
                 [("Supplier Payables", paid, 0)] +
                 [("Cash" if pp["mode"] == "Cash" else "Bank", 0, r2(pp["amount"])) for pp in data.get("payments", [])])
    _audit(con, "purchase", "create", {}, {"purchase_no": no, "grand_total": grand})
    return pid

def create_sale(con, data):
    """data: customer_id, items[{unit_id?, product_id?, selling_price?, discount?}], payments[{mode,amount}],
    advances[{advance_id, amount}], bill_discount, charges, salesperson_id, notes, request_id, gst_mode.
    Items with a unit_id sell that exact saree; without one they sell from product stock (qty=1 each)."""
    s = _settings(con)
    if data.get("request_id"):
        row = con.execute("SELECT id FROM sales_invoices WHERE request_id=?", (data["request_id"],)).fetchone()
        if row: return row["id"]
    cust = None
    if data.get("customer_id"):
        cust = con.execute("SELECT * FROM customers WHERE id=?", (data["customer_id"],)).fetchone()
        if not cust: raise ValueError("Customer not found")
    intra = _intra(con, cust["state"] if cust else "")
    mode = data.get("gst_mode", s["default_gst_mode"])
    prev_out = customer_balance(con, data["customer_id"]) if cust else 0.0
    # Resolve items
    resolved = []
    for it in data["items"]:
        if it.get("unit_id"):
            u = con.execute("SELECT * FROM product_units WHERE id=?", (it["unit_id"],)).fetchone()
            if not u: raise ValueError("Barcode unit not found")
            if u["status"] != "Available":
                raise ValueError(f"Barcode {u['barcode']} is {u['status']} and cannot be sold again")
            prod = con.execute("SELECT * FROM products WHERE id=?", (u["product_id"],)).fetchone()
            resolved.append({"product": prod, "unit": u, "price": it.get("selling_price", prod["selling_price"]),
                             "discount": it.get("discount", 0), "qty": 1})
        else:
            prod = con.execute("SELECT * FROM products WHERE id=?", (it["product_id"],)).fetchone()
            if not prod: raise ValueError("Product not found")
            if prod["current_stock"] < 1 and not s["allow_negative_stock"]:
                raise ValueError(f"Not enough stock for {prod['name']} (stock {prod['current_stock']})")
            resolved.append({"product": prod, "unit": None, "price": it.get("selling_price", prod["selling_price"]),
                             "discount": it.get("discount", 0), "qty": 1})
    bill_disc = r2(data.get("bill_discount", 0))
    gross_sum = sum(x["price"]*x["qty"] - x["discount"] for x in resolved)
    if gross_sum <= 0: raise ValueError("Sale total must be positive")
    sub = tax = cg = sg = ig = pdisc = 0.0
    calc_lines = []
    for x in resolved:
        share = r2(bill_disc * (x["price"]*x["qty"] - x["discount"]) / gross_sum) if bill_disc else 0.0
        lc = line_calc(x["price"], x["qty"], x["discount"] + share, x["product"]["gst_rate"], mode, intra)
        calc_lines.append((x, lc, share)); sub += x["price"]*x["qty"]; pdisc += x["discount"] + share
        tax += lc["taxable"]; cg += lc["cgst"]; sg += lc["sgst"]; ig += lc["igst"]
    charges = r2(data.get("charges", 0))
    grand = r2(tax + cg + sg + ig + charges)
    # Advances
    adv_total = 0.0
    for a in data.get("advances", []):
        adv = con.execute("SELECT * FROM customer_advances WHERE id=?", (a["advance_id"],)).fetchone()
        if not adv or adv["balance"] < a["amount"] - 0.01:
            raise ValueError("Advance balance insufficient for adjustment")
        adv_total += r2(a["amount"])
    pay_total = r2(sum(p["amount"] for p in data.get("payments", [])))
    if pay_total + adv_total > grand + 0.01:
        raise ValueError("Payments + advance adjustment exceed invoice total")
    balance_due = r2(grand - pay_total - adv_total)
    no = _next_no(con, "sales_invoices", "invoice_no", _settings(con)["invoice_prefix"])
    cur = con.execute("INSERT INTO sales_invoices (invoice_no, customer_id, salesperson_id, subtotal, product_discount, bill_discount, taxable, cgst, sgst, igst, charges, grand_total, received, previous_outstanding, advance_adjusted, balance_due, notes, request_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (no, data.get("customer_id"), data.get("salesperson_id"), r2(sub), r2(pdisc), bill_disc,
         r2(tax), r2(cg), r2(sg), r2(ig), charges, grand, r2(pay_total + adv_total), prev_out, adv_total, balance_due,
         data.get("notes",""), data.get("request_id")))
    sid = cur.lastrowid
    for x, lc, share in calc_lines:
        con.execute("INSERT INTO sales_items (sales_id, product_id, unit_id, barcode, qty, mrp, selling_price, discount, taxable, gst_rate, cgst, sgst, igst, amount) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (sid, x["product"]["id"], x["unit"]["id"] if x["unit"] else None, x["unit"]["barcode"] if x["unit"] else "",
                     x["qty"], x["product"]["mrp"], x["price"], r2(x["discount"]+share), lc["taxable"], x["product"]["gst_rate"], lc["cgst"], lc["sgst"], lc["igst"], lc["amount"]))
        if x["unit"]:
            con.execute("UPDATE product_units SET status='Sold', date_sold=date('now','localtime'), sales_invoice_id=? WHERE id=?", (sid, x["unit"]["id"]))
            con.execute("INSERT INTO stock_movements (product_id, unit_id, barcode, movement_type, qty, ref_type, ref_id) VALUES (?,?,?,?,?,?,?)",
                        (x["product"]["id"], x["unit"]["id"], x["unit"]["barcode"], "OUT", 1, "sale", sid))
        else:
            con.execute("INSERT INTO stock_movements (product_id, movement_type, qty, ref_type, ref_id) VALUES (?,?,?,?,?)",
                        (x["product"]["id"], "OUT", 1, "sale", sid))
        con.execute("UPDATE products SET current_stock=current_stock-1 WHERE id=?", (x["product"]["id"],))
    for p in data.get("payments", []):
        con.execute("INSERT INTO sales_payments (sales_id, mode, amount) VALUES (?,?,?)", (sid, p["mode"], r2(p["amount"])))
        if p["mode"] != "Credit":
            _cash_bank(con, p["mode"], p["amount"], "IN", f"Sale {no}", "sale", sid)
    for a in data.get("advances", []):
        con.execute("INSERT INTO advance_adjustments (advance_id, sales_id, amount) VALUES (?,?,?)", (a["advance_id"], sid, r2(a["amount"])))
        con.execute("UPDATE customer_advances SET balance=balance-? WHERE id=?", (r2(a["amount"]), a["advance_id"]))
        con.execute("UPDATE customer_advances SET status='Closed' WHERE id=? AND balance<=0.01", (a["advance_id"],))
    if cust:
        _ledger(con, cust["id"], "SALE", no, f"Sale {no}", grand, 0, "sale", sid)
        if pay_total + adv_total:
            _ledger(con, cust["id"], "RCPT", no, f"Payment against {no}", 0, r2(pay_total + adv_total), "sale", sid)
    debits = []
    for p in data.get("payments", []):
        if p["mode"] != "Credit":
            debits.append(("Cash" if p["mode"] == "Cash" else "Bank", r2(p["amount"]), 0))
    if adv_total: debits.append(("Customer Advances", adv_total, 0))
    if balance_due: debits.append(("Customer Receivables", balance_due, 0))
    _journal(con, no, f"Sale {no}", "sale", sid,
             debits + [("Sales", 0, r2(tax + charges)), ("GST Output", 0, r2(cg+sg+ig))])  # charges ride on Sales so the journal always balances to grand_total
    _audit(con, "sales", "create", {}, {"invoice_no": no, "grand_total": grand})
    return sid

def collect_udhar(con, customer_id, amount, mode, notes=""):
    if amount <= 0: raise ValueError("Collection amount must be positive")
    bal = customer_balance(con, customer_id)
    if amount > bal + 0.01: raise ValueError(f"Collection ₹{amount} exceeds outstanding ₹{bal}")
    rec_no = _next_no(con, "customer_ledger", "voucher", "RCPT")
    _ledger(con, customer_id, rec_no, "", notes or "Udhar collection", 0, r2(amount), "collection", 0)
    _cash_bank(con, mode, amount, "IN", f"Udhar collection {rec_no}", "collection", 0)
    _journal(con, rec_no, "Udhar collection", "collection", 0,
             [("Cash" if mode == "Cash" else "Bank", r2(amount), 0), ("Customer Receivables", 0, r2(amount))])
    _audit(con, "udhar", "collect", {"balance_before": bal}, {"amount": amount, "mode": mode})
    return rec_no

def receive_advance(con, customer_id, amount, mode, notes=""):
    if amount <= 0: raise ValueError("Advance must be positive")
    no = _next_no(con, "customer_advances", "receipt_no", "ADV")
    cur = con.execute("INSERT INTO customer_advances (customer_id, receipt_no, amount, balance, mode, notes) VALUES (?,?,?,?,?,?)",
                      (customer_id, no, r2(amount), r2(amount), mode, notes))
    _cash_bank(con, mode, amount, "IN", f"Advance {no}", "advance", cur.lastrowid)
    _journal(con, no, f"Advance received {no}", "advance", cur.lastrowid,
             [("Cash" if mode == "Cash" else "Bank", r2(amount), 0), ("Customer Advances", 0, r2(amount))])
    _audit(con, "advance", "receive", {}, {"receipt_no": no, "amount": amount})
    return cur.lastrowid

def sales_return(con, sales_id, unit_id, condition="Saleable", refund_mode="Credit", reason=""):
    item = con.execute("SELECT * FROM sales_items WHERE sales_id=? AND unit_id=?", (sales_id, unit_id)).fetchone()
    if not item: raise ValueError("This unit was not on that invoice")
    if con.execute("SELECT 1 FROM sales_returns WHERE sales_id=? AND unit_id=?", (sales_id, unit_id)).fetchone():
        raise ValueError("This unit has already been returned")
    inv = con.execute("SELECT * FROM sales_invoices WHERE id=?", (sales_id,)).fetchone()
    unit = con.execute("SELECT * FROM product_units WHERE id=?", (unit_id,)).fetchone()
    amt = r2(item["amount"])
    con.execute("INSERT INTO sales_returns (sales_id, unit_id, product_id, amount, reason, condition, refund_mode) VALUES (?,?,?,?,?,?,?)",
                (sales_id, unit_id, item["product_id"], amt, reason, condition, refund_mode))
    if condition == "Saleable":
        con.execute("UPDATE product_units SET status='Available', date_sold='', sales_invoice_id=NULL WHERE id=?", (unit_id,))
        con.execute("UPDATE products SET current_stock=current_stock+1 WHERE id=?", (item["product_id"],))
        con.execute("INSERT INTO stock_movements (product_id, unit_id, barcode, movement_type, qty, ref_type, ref_id) VALUES (?,?,?,?,?,?,?)",
                    (item["product_id"], unit_id, unit["barcode"], "IN", 1, "sales_return", sales_id))
    else:
        con.execute("UPDATE product_units SET status='Damaged' WHERE id=?", (unit_id,))
    note_no = _next_no(con, "credit_notes", "note_no", "CN")
    con.execute("INSERT INTO credit_notes (note_no, sales_id, customer_id, amount, reason) VALUES (?,?,?,?,?)",
                (note_no, sales_id, inv["customer_id"], amt, reason))
    if inv["customer_id"]:
        _ledger(con, inv["customer_id"], note_no, inv["invoice_no"], f"Sales return / credit note {note_no}", 0, amt, "sales_return", sales_id)
    _journal(con, note_no, f"Sales return {note_no}", "sales_return", sales_id,
             [("Sales Returns", r2(item["taxable"]), 0), ("GST Output", r2(item["cgst"]+item["sgst"]+item["igst"]), 0),
              ("Customer Receivables", 0, amt)])
    if refund_mode == "Cash":
        _cash_bank(con, "Cash", amt, "OUT", f"Return refund {note_no}", "sales_return", sales_id)
    _audit(con, "sales_return", "create", {"invoice": inv["invoice_no"]}, {"credit_note": note_no, "amount": amt, "condition": condition})
    return note_no

def purchase_return(con, purchase_id, reason="", unit_id=None, product_id=None, qty=1):
    """Return purchased saree(s) to the supplier. Stock falls, supplier payable falls,
    and the original purchase's taxable + GST portions are reversed in the journal.
    A unit already sold, or already returned, cannot be returned to the supplier."""
    inv = con.execute("SELECT * FROM purchase_invoices WHERE id=?", (purchase_id,)).fetchone()
    if not inv: raise ValueError("Purchase invoice not found")
    if unit_id:
        units = [con.execute("SELECT * FROM product_units WHERE id=?", (unit_id,)).fetchone()]
        if not units[0]: raise ValueError("Barcode unit not found")
    else:
        if not product_id: raise ValueError("Give a barcode, or a product + quantity, to return")
        units = con.execute("SELECT * FROM product_units WHERE purchase_invoice_id=? AND product_id=? AND status='Available' ORDER BY id LIMIT ?",
                            (purchase_id, product_id, int(qty))).fetchall()
        if len(units) < int(qty):
            raise ValueError(f"Only {len(units)} available unit(s) from this purchase can be returned")
    total = 0.0
    for u in units:
        if u["status"] != "Available":
            raise ValueError(f"Barcode {u['barcode']} is {u['status']} and cannot be returned to the supplier")
        if u["purchase_invoice_id"] != purchase_id:
            raise ValueError(f"Barcode {u['barcode']} did not come from purchase {inv['purchase_no']}")
        item = con.execute("SELECT * FROM purchase_items WHERE purchase_id=? AND product_id=?", (purchase_id, u["product_id"])).fetchone()
        if item and item["qty"]:
            per_tax = r2(item["taxable"] / item["qty"]); per_gst = r2((item["cgst"] + item["sgst"] + item["igst"]) / item["qty"])
            per_amt = r2(per_tax + per_gst)
        else:
            per_tax, per_gst, per_amt = r2(u["purchase_price"]), 0.0, r2(u["purchase_price"])
        con.execute("INSERT INTO purchase_returns (purchase_id, product_id, unit_id, qty, amount, reason) VALUES (?,?,?,?,?,?)",
                    (purchase_id, u["product_id"], u["id"], 1, per_amt, reason))
        con.execute("UPDATE product_units SET status='Returned' WHERE id=?", (u["id"],))
        con.execute("UPDATE products SET current_stock=current_stock-1 WHERE id=?", (u["product_id"],))
        con.execute("INSERT INTO stock_movements (product_id, unit_id, barcode, movement_type, qty, ref_type, ref_id, reason) VALUES (?,?,?,?,?,?,?,?)",
                    (u["product_id"], u["id"], u["barcode"], "OUT", -1, "purchase_return", purchase_id, reason))
        _journal(con, inv["purchase_no"] + "-RET", f"Purchase return {inv['purchase_no']}", "purchase_return", purchase_id,
                 [("Supplier Payables", per_amt, 0), ("Purchases", 0, per_tax), ("GST Input", 0, per_gst)])
        total += per_amt
    con.execute("UPDATE purchase_invoices SET outstanding=MAX(0, outstanding-?) WHERE id=?", (r2(total), purchase_id))
    _audit(con, "purchase_return", "create", {"purchase_no": inv["purchase_no"]}, {"amount": r2(total), "reason": reason, "units": len(units)})
    return r2(total)

def supplier_payment(con, supplier_id, amount, mode, purchase_id=None, notes=""):
    if amount <= 0: raise ValueError("Payment amount must be positive")
    bal = supplier_balance(con, supplier_id)
    if amount > bal + 0.01: raise ValueError(f"Payment ₹{amount} exceeds supplier outstanding ₹{bal}")
    con.execute("INSERT INTO purchase_payments (purchase_id, supplier_id, amount, mode, notes) VALUES (?,?,?,?,?)",
                (purchase_id, supplier_id, r2(amount), mode, notes))
    if purchase_id:
        con.execute("UPDATE purchase_invoices SET paid=paid+?, outstanding=MAX(0, outstanding-?) WHERE id=?", (r2(amount), r2(amount), purchase_id))
    _cash_bank(con, mode, amount, "OUT", notes or f"Supplier payment", "supplier_payment", supplier_id)
    sup = con.execute("SELECT name FROM suppliers WHERE id=?", (supplier_id,)).fetchone()
    _journal(con, f"SUPPAY-{supplier_id}", f"Supplier payment to {sup['name'] if sup else supplier_id}", "supplier_payment", supplier_id,
             [("Supplier Payables", r2(amount), 0), ("Cash" if mode == "Cash" else "Bank", 0, r2(amount))])
    _audit(con, "supplier_payment", "create", {"balance_before": bal}, {"amount": amount, "mode": mode})
    return True

def supplier_ledger(con, supplier_id):
    """Derived ledger: opening + purchases increase what is owed, payments and
    purchase returns decrease it. Running balance is what is owed to the supplier."""
    sup = con.execute("SELECT * FROM suppliers WHERE id=?", (supplier_id,)).fetchone()
    if not sup: raise ValueError("Supplier not found")
    rows = []
    bal = r2(sup["opening_balance"])
    if bal: rows.append({"date": "", "voucher": "OPEN", "particulars": "Opening balance", "increase": bal, "decrease": 0.0, "running": bal})
    events = []
    for r in con.execute("SELECT purchase_date d, purchase_no v, grand_total a FROM purchase_invoices WHERE supplier_id=? AND status='Posted'", (supplier_id,)):
        events.append((r["d"], r["v"], f"Purchase {r['v']}", r["a"], 0.0))
    for r in con.execute("SELECT pay_date d, amount a, mode m FROM purchase_payments WHERE supplier_id=?", (supplier_id,)):
        events.append((r["d"], "PAY", f"Payment ({r['m']})", 0.0, r["a"]))
    for r in con.execute("SELECT pr.return_date d, pr.amount a, pi.purchase_no v FROM purchase_returns pr JOIN purchase_invoices pi ON pi.id=pr.purchase_id WHERE pi.supplier_id=?", (supplier_id,)):
        events.append((r["d"], "RET", f"Purchase return against {r['v']}", 0.0, r["a"]))
    for d, v, part, inc, dec in sorted(events, key=lambda x: (x[0] or "", x[1])):
        bal = r2(bal + inc - dec)
        rows.append({"date": d, "voucher": v, "particulars": part, "increase": r2(inc), "decrease": r2(dec), "running": bal})
    return {"supplier": dict(sup), "balance": bal, "rows": rows}

def make_backup(db_path, dest_dir, name=None):
    """Copy the live .db file to dest_dir with a timestamped name. Returns the new path.
    Callers must have no open write transaction; the server closes its connection first."""
    import shutil, datetime
    from pathlib import Path
    dest_dir = Path(dest_dir); dest_dir.mkdir(parents=True, exist_ok=True)
    if name is None:
        name = f"saree-backup-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}.db"
    dest = dest_dir / name
    shutil.copyfile(str(db_path), str(dest))
    return dest

def copy_backup_to_drive(backup_path, drive_folder):
    """Copy a backup file into the user's Google Drive folder (Google Drive for
    Desktop syncs it to their Gmail Drive account). No credentials are stored in
    the app; the sync is done by Google's own desktop app, signed in by the owner."""
    import shutil
    from pathlib import Path
    folder = Path(drive_folder)
    if not folder.is_dir():
        raise ValueError(f"Google Drive folder not found: {drive_folder}. Install Google Drive for Desktop, sign in with your Gmail, then set the folder in Settings (for example a folder inside your Google Drive folder).")
    dest = folder / Path(backup_path).name
    shutil.copyfile(str(backup_path), str(dest))
    return dest

def dashboard(con, date_from, date_to):
    def one(sql, args=()):
        r = con.execute(sql, args).fetchone()
        return r2(r[0]) if r and r[0] is not None else 0.0
    def cnt(sql, args=()):
        r = con.execute(sql, args).fetchone()
        return int(r[0] or 0) if r else 0
    sales = con.execute("SELECT * FROM sales_invoices WHERE invoice_date BETWEEN ? AND ? AND status='Posted'", (date_from, date_to)).fetchall()
    total_sales = r2(sum(x["grand_total"] for x in sales))
    pay = {}
    for p in con.execute("SELECT mode, SUM(amount) s FROM sales_payments sp JOIN sales_invoices si ON si.id=sp.sales_id WHERE si.invoice_date BETWEEN ? AND ? GROUP BY mode", (date_from, date_to)):
        pay[p["mode"]] = r2(p["s"])
    return {
        "today_sales": total_sales, "cash_sales": pay.get("Cash", 0), "upi_sales": pay.get("UPI", 0),
        "card_sales": pay.get("Card", 0), "bank_sales": pay.get("Bank Transfer", 0), "credit_sales": r2(sum(x["balance_due"] for x in sales)),
        "collections": one("SELECT SUM(amount) FROM cash_transactions WHERE txn_type='IN' AND txn_date BETWEEN ? AND ?", (date_from, date_to)),
        "advance_received": one("SELECT SUM(amount) FROM customer_advances WHERE adv_date BETWEEN ? AND ?", (date_from, date_to)),
        "purchases": one("SELECT SUM(grand_total) FROM purchase_invoices WHERE purchase_date BETWEEN ? AND ?", (date_from, date_to)),
        "expenses": one("SELECT SUM(amount) FROM expenses WHERE exp_date BETWEEN ? AND ?", (date_from, date_to)),
        "total_stock": cnt("SELECT SUM(current_stock) FROM products"),
        "inventory_cost": one("SELECT SUM(current_stock*purchase_price) FROM products"),
        "inventory_mrp": one("SELECT SUM(current_stock*mrp) FROM products"),
        "low_stock": cnt("SELECT COUNT(*) FROM products WHERE current_stock<=min_stock_alert AND current_stock>0"),
        "out_of_stock": cnt("SELECT COUNT(*) FROM products WHERE current_stock<=0"),
        "damaged": cnt("SELECT COUNT(*) FROM product_units WHERE status='Damaged'"),
        "total_customers": cnt("SELECT COUNT(*) FROM customers"),
        "total_udhar": one("SELECT SUM(debit)-SUM(credit) FROM customer_ledger"),
        "total_advances": one("SELECT SUM(balance) FROM customer_advances WHERE status!='Closed'"),
        "total_supplier_outstanding": one("SELECT SUM(grand_total)- (SELECT COALESCE(SUM(amount),0) FROM purchase_payments) FROM purchase_invoices WHERE status='Posted'"),
        "cash_balance": one("SELECT SUM(CASE WHEN txn_type='IN' THEN amount ELSE -amount END) FROM cash_transactions"),
        "bank_balance": one("SELECT SUM(CASE WHEN txn_type='IN' THEN amount ELSE -amount END) FROM bank_transactions"),
        "daily_sales": [{"date": d["invoice_date"], "total": r2(d["t"])} for d in con.execute(
            "SELECT invoice_date, SUM(grand_total) t FROM sales_invoices WHERE invoice_date BETWEEN ? AND ? GROUP BY invoice_date ORDER BY invoice_date", (date_from, date_to))],
        "category_sales": [{"category": (c["name"] if c else "—"), "total": r2(t)} for c, t in [
            (con.execute("SELECT name FROM categories WHERE id=?", (r["cid"],)).fetchone(), r["t"]) for r in con.execute(
            "SELECT p.category_id cid, SUM(si.amount) t FROM sales_items si JOIN products p ON p.id=si.product_id JOIN sales_invoices s ON s.id=si.sales_id WHERE s.invoice_date BETWEEN ? AND ? GROUP BY p.category_id ORDER BY t DESC", (date_from, date_to))]],
    }

def ageing(con, customer_id=None):
    today = date.today().isoformat()
    rows = []
    q = "SELECT * FROM sales_invoices WHERE balance_due>0.01 AND status='Posted'"
    args = []
    if customer_id: q += " AND customer_id=?"; args.append(customer_id)
    for inv in con.execute(q, args):
        days = (date.fromisoformat(today) - date.fromisoformat(inv["invoice_date"])).days
        bucket = "0-30" if days <= 30 else "31-60" if days <= 60 else "61-90" if days <= 90 else "91-180" if days <= 180 else "180+"
        rows.append({"invoice_no": inv["invoice_no"], "customer_id": inv["customer_id"], "date": inv["invoice_date"], "days": days, "bucket": bucket, "due": inv["balance_due"]})
    return rows

def label_data(con, template_id, unit_ids):
    tpl = con.execute("SELECT * FROM label_templates WHERE id=?", (template_id,)).fetchone()
    if not tpl: raise ValueError("Label template not found")
    s = _settings(con)
    fields = json.loads(tpl["fields_json"])
    units = []
    for uid in unit_ids:
        u = con.execute("SELECT * FROM product_units WHERE id=?", (uid,)).fetchone()
        if not u: continue
        p = con.execute("SELECT p.*, c.name cat FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=?", (u["product_id"],)).fetchone()
        units.append({"barcode": u["barcode"], "product": p["name"], "sku": p["sku"] or "", "category": p["cat"] or "",
                      "colour": p["colour"], "fabric": p["fabric"], "design": p["design_name"],
                      "mrp": p["mrp"], "selling_price": p["selling_price"], "showroom": s["showroom_name"]})
    return {"template": dict(tpl), "fields": fields, "showroom": s["showroom_name"], "units": units}

"""Auto-update — the user asked: future updates must happen automatically.

Rules (hard):
- The database in data/ and backups/ is NEVER copied, moved or deleted by an update.
- An update is never applied while the app is running a sale: it is downloaded in
  the background and installed on the NEXT launch, from a staging folder.
- Every install first takes a backup of the code being replaced, so a bad update
  can be rolled back by restoring backups/<version>/.
- A zip whose SHA-256 does not match version.json is rejected, never installed.
- Modes (company_settings.auto_update_mode):
    install_on_restart (default) — check on launch, download, install next launch
    notify_only — check only, record the available version, do not download
    off — do not check

Channel format (version.json), same shape as the Weighing Scale / Parchi channel:
    {"version": "0.2.0", "zip_url": "https://.../saree-erp-0.2.0.zip",
     "sha256": "...", "changelog": "...", "min_version": "0.1.0"}
zip_url may also be a local file path (used by tests and by an offline channel folder).
"""
from __future__ import annotations
import hashlib, json, shutil, urllib.request, zipfile
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent.parent
VERSION_FILE = APP_ROOT / "version.json"
PENDING_FILE = APP_ROOT / "pending_update.json"
STAGING_DIR = APP_ROOT / ".update_staging"
BACKUP_ROOT = APP_ROOT / "backups"
PROTECTED = {"data", "backups", ".update_staging", "__pycache__"}

def current_version():
    try:
        return json.loads(VERSION_FILE.read_text())["version"]
    except Exception:
        return "0.0.0"

def _ver_tuple(v):
    return tuple(int(x) for x in str(v).strip().lstrip("v").split(".") + ["0"] * (3 - len(str(v).split("."))))

def is_newer(new, cur):
    try: return _ver_tuple(new) > _ver_tuple(cur)
    except Exception: return str(new) != str(cur)

def fetch_channel(channel_url):
    """channel_url: https URL or local path to version.json."""
    if channel_url.startswith("http"):
        with urllib.request.urlopen(channel_url, timeout=20) as r:
            return json.loads(r.read().decode())
    return json.loads(Path(channel_url).read_text())

def check(channel_url, mode="install_on_restart"):
    """Returns dict(available, current, latest, notes). Downloads only in install_on_restart mode."""
    cur = current_version()
    info = fetch_channel(channel_url)
    latest = info.get("version", cur)
    out = {"current": cur, "latest": latest, "available": is_newer(latest, cur),
           "changelog": info.get("changelog", ""), "downloaded": False, "staged_for_restart": False}
    if not out["available"] or mode != "install_on_restart":
        return out
    staged = download(info)
    out["downloaded"] = True
    out["staged_for_restart"] = staged is not None
    return out

def download(info):
    url, expect = info["zip_url"], info.get("sha256", "")
    if STAGING_DIR.exists(): shutil.rmtree(STAGING_DIR)
    STAGING_DIR.mkdir(parents=True)
    dest = STAGING_DIR / "update.zip"
    if url.startswith("http"):
        urllib.request.urlretrieve(url, dest)
    else:
        shutil.copyfile(url, dest)
    if expect:
        h = hashlib.sha256(dest.read_bytes()).hexdigest()
        if h.lower() != expect.lower():
            shutil.rmtree(STAGING_DIR)
            raise ValueError(f"Update rejected: SHA-256 mismatch (expected {expect[:12]}…, got {h[:12]}…) — not installed.")
    with zipfile.ZipFile(dest) as z:
        z.extractall(STAGING_DIR / "extracted")
    PENDING_FILE.write_text(json.dumps({"version": info["version"], "staged": str(STAGING_DIR / "extracted")}))
    return str(STAGING_DIR / "extracted")

def apply_pending():
    """Called at startup, BEFORE the server starts serving. Returns version installed or None."""
    if not PENDING_FILE.exists(): return None
    try: pending = json.loads(PENDING_FILE.read_text())
    except Exception: PENDING_FILE.unlink(missing_ok=True); return None
    src = Path(pending["staged"])
    if not src.exists():
        PENDING_FILE.unlink(missing_ok=True); return None
    version = pending["version"]
    backup = BACKUP_ROOT / f"code-before-{version}"
    if backup.exists(): shutil.rmtree(backup)
    backup.mkdir(parents=True)
    # Back up only code that the update replaces.
    for name in ("app", "web", "tools"):
        if (APP_ROOT / name).exists():
            shutil.copytree(APP_ROOT / name, backup / name, ignore=shutil.ignore_patterns("__pycache__"))
    for item in src.rglob("*"):
        if item.is_file():
            rel = item.relative_to(src)
            if rel.parts[0] in PROTECTED: continue
            dest = APP_ROOT / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(item, dest)
    (BACKUP_ROOT / f"update-{version}.log").write_text(f"Installed {version}; code backup at {backup}\n")
    PENDING_FILE.unlink(missing_ok=True)
    if STAGING_DIR.exists(): shutil.rmtree(STAGING_DIR)
    return version

def rollback(version):
    backup = BACKUP_ROOT / f"code-before-{version}"
    if not backup.exists(): raise ValueError(f"No backup found for {version}")
    for name in ("app", "web", "tools"):
        if (backup / name).exists():
            if (APP_ROOT / name).exists(): shutil.rmtree(APP_ROOT / name)
            shutil.copytree(backup / name, APP_ROOT / name, ignore=shutil.ignore_patterns("__pycache__"))
    return True

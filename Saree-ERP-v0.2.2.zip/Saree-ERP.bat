@echo off
REM Saree Showroom ERP - double-click to start.
REM Uses the BUNDLED Python in python-win\, no system Python needed.
REM Opens http://127.0.0.1:8765 in your browser.
REM Your database is data\saree.db inside THIS folder - back it up before updating.
cd /d "%~dp0"
if exist "python-win\python.exe" (
  start "" http://127.0.0.1:8765
  set SAREE_ERP_DATA_DIR=%~dp0data
  python-win\python.exe app\server.py
) else (
  echo ERROR: python-win\python.exe not found. Re-extract the full zip.
  pause
)

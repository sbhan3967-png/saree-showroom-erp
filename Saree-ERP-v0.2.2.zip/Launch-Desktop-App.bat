@echo off
REM Saree Showroom ERP - desktop launcher.
REM This package is NOT Electron: the .exe is a .NET launcher that starts the
REM bundled Python engine and opens Chrome/Edge in app-window mode.
REM If the .exe is missing, fall back to Saree-ERP.bat (bundled Python + browser).
cd /d "%~dp0"
if exist "Saree Showroom ERP.exe" (
  start "" "Saree Showroom ERP.exe"
) else (
  call Saree-ERP.bat
)

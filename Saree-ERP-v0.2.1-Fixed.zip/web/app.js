/* Saree Showroom ERP — Modern Interactive UI & POS Application */
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

const inr = n => '₹' + Number(n || 0).toLocaleString('en-IN', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});

const inrInt = n => '₹' + Math.round(Number(n || 0)).toLocaleString('en-IN');

function esc(s) {
  return String(s ?? '').replace(/[&<>"]/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'
  }[c]));
}

async function api(path, method = 'GET', body) {
  const r = await fetch(path, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined
  });
  const j = await r.json();
  if (!r.ok) throw new Error(j.error || 'Server error');
  return j;
}

// --- Code39 Barcode Generator (Scannable SVG) ---
const C39 = {
  '0':'000110100','1':'100100001','2':'001100001','3':'101100000','4':'000110001',
  '5':'100110000','6':'001110000','7':'000100101','8':'100100100','9':'001100100',
  'A':'100001001','B':'001001001','C':'101001000','D':'000011001','E':'100011000',
  'F':'001011000','G':'000001101','H':'100001100','I':'001001100','J':'000011100',
  'K':'100000011','L':'001000011','M':'101000010','N':'000010011','O':'100010010',
  'P':'001010010','Q':'000000111','R':'100000110','S':'001000110','T':'000010110',
  'U':'110000001','V':'011000001','W':'111000000','X':'010010001','Y':'110010000',
  'Z':'011010000','-':'010000101','.':'110000100',' ':'011000100','*':'010010100',
  '$':'010101000','/':'010100010','+':'010001010','%':'000101010'
};

function barcodeSVG(code, h = 32) {
  code = '*' + String(code).toUpperCase().replace(/[^0-9A-Z .\-$/+%]/g, '') + '*';
  let x = 0, rects = '';
  for (const ch of code) {
    const pat = C39[ch] || C39['0'];
    for (let i = 0; i < 9; i++) {
      const w = pat[i] === '1' ? 3 : 1;
      if (i % 2 === 0) rects += `<rect x="${x}" y="0" width="${w}" height="${h}"/>`;
      x += w + 1;
    }
    x += 2;
  }
  return `<svg width="${x}" height="${h}" viewBox="0 0 ${x} ${h}" xmlns="http://www.w3.org/2000/svg" style="display:block;margin:auto;">${rects}</svg>`;
}

// --- Application State ---
let state = {
  page: 'dash',
  dashRange: 'today',
  cats: [],
  products: [],
  customers: [],
  suppliers: [],
  templates: [],
  settings: {},
  version: '',
  pos: [],
  suppliersSubTab: 'pay',
  accountsSubTab: 'cash'
};

// --- Toast System ---
function toast(msg, type = 'info') {
  const t = $('#toast');
  const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : type === 'warning' ? '⚠️' : 'ℹ️';
  t.innerHTML = `<span style="font-size:16px">${icon}</span> <span>${esc(msg)}</span>`;
  t.style.display = 'flex';
  t.style.borderLeftColor = type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : type === 'warning' ? '#f59e0b' : '#c59b27';
  clearTimeout(t._timer);
  t._timer = setTimeout(() => { t.style.display = 'none'; }, 3800);
}

// --- Modal System ---
function showModal(title, bodyHTML, footerHTML = '', sizeClass = '') {
  const container = $('#modal-container');
  container.innerHTML = `
    <div class="modal-dialog ${sizeClass}">
      <div class="modal-header">
        <div class="modal-title">${title}</div>
        <button class="modal-close" onclick="closeModal()">✕</button>
      </div>
      <div class="modal-body">${bodyHTML}</div>
      ${footerHTML ? `<div class="modal-footer">${footerHTML}</div>` : ''}
    </div>
  `;
  container.style.display = 'flex';
}

function closeModal() {
  const container = $('#modal-container');
  container.style.display = 'none';
  container.innerHTML = '';
}

// Global Escape key to close modal
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
  if (e.key === 'F1') { e.preventDefault(); nav('dash'); }
  if (e.key === 'F2') { e.preventDefault(); nav('pos'); }
  if (e.key === 'F3') { e.preventDefault(); nav('products'); }
  if (e.key === 'F4') { e.preventDefault(); nav('accounts'); }
});

// Click outside modal dialog to close
document.addEventListener('click', e => {
  if (e.target.id === 'modal-container') closeModal();
});

// --- Live Clock ---
function startClock() {
  function tick() {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const dateStr = now.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
    const el = $('#live-clock');
    if (el) el.innerHTML = `<span style="opacity:0.6">🕒</span> <span>${timeStr}</span> <span style="opacity:0.4">•</span> <span>${dateStr}</span>`;
  }
  tick();
  setInterval(tick, 1000);
}

// --- Navigation ---
function nav(p) {
  state.page = p;
  $$('.sidebar button').forEach(b => b.classList.toggle('on', b.dataset.page === p));
  render();
}

document.addEventListener('click', e => {
  const b = e.target.closest('[data-page]');
  if (b) nav(b.dataset.page);
});

// --- Table Formatter Helper ---
function table(head, rows, alignRights = []) {
  return `
    <div class="table-responsive">
      <table>
        <thead>
          <tr>
            ${head.map((h, i) => `<th class="${alignRights.includes(i) ? 'num' : ''}">${h}</th>`).join('')}
          </tr>
        </thead>
        <tbody>
          ${rows.length ? rows.map(r => `
            <tr>
              ${r.map((c, i) => `<td class="${alignRights.includes(i) ? 'num' : ''}">${c}</td>`).join('')}
            </tr>
          `).join('') : `<tr><td colspan="${head.length}" style="text-align:center;padding:24px;color:#94a3b8">No records found.</td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}

// --- Base Data Loader ---
async function loadBase() {
  try {
    const [cats, customers, suppliers, templates, ver, set] = await Promise.all([
      api('/api/categories'),
      api('/api/customers'),
      api('/api/suppliers'),
      api('/api/label-templates'),
      api('/api/version'),
      api('/api/settings')
    ]);
    state.cats = cats;
    state.customers = customers;
    state.suppliers = suppliers;
    state.templates = templates;
    state.version = ver.version;
    state.settings = set || {};
    
    $('#ver').textContent = `v${ver.version} • Single Showroom`;
    if (set && set.showroom_name) {
      $('#top-showroom-name').textContent = set.showroom_name;
      $('#brand-title').textContent = set.showroom_name.length > 18 ? set.showroom_name.slice(0, 18) + '…' : set.showroom_name;
    }
  } catch (e) {
    console.error('Failed to load base data:', e);
  }
}

// --- Main Render Function ---
async function render() {
  const m = $('#main');
  const p = state.page;

  // 1. DASHBOARD
  if (p === 'dash') {
    renderDashboard(m);
    return;
  }

  // 2. PRODUCT MASTER
  if (p === 'products') {
    renderProducts(m);
    return;
  }

  // 3. POS BILLING
  if (p === 'pos') {
    renderPosBilling(m);
    return;
  }

  // 4. NEW PURCHASE
  if (p === 'purchase') {
    renderNewPurchase(m);
    return;
  }

  // 5. PURCHASE REGISTER
  if (p === 'purchases') {
    renderPurchaseRegister(m);
    return;
  }

  // 6. SUPPLIERS & LEDGER
  if (p === 'suppliers') {
    renderSuppliers(m);
    return;
  }

  // 7. CUSTOMERS & KHATA
  if (p === 'customers') {
    renderCustomers(m);
    return;
  }

  // 8. SALES REGISTER
  if (p === 'sales') {
    renderSalesRegister(m);
    return;
  }

  // 9. BARCODE & TAG STUDIO
  if (p === 'labels') {
    renderLabelsStudio(m);
    return;
  }

  // 10. STOCK ADJUSTMENT & MOVEMENTS
  if (p === 'stock') {
    renderStockAdjustment(m);
    return;
  }

  // 11. DAY BOOK & ACCOUNTS
  if (p === 'accounts') {
    renderDayBook(m);
    return;
  }

  // 12. REPORTS & UDHAR AGEING
  if (p === 'reports') {
    renderReports(m);
    return;
  }

  // 13. SETTINGS & CLOUD BACKUP
  if (p === 'settings') {
    renderSettings(m);
    return;
  }
}

// ==========================================
// 1. DASHBOARD VIEW
// ==========================================
async function renderDashboard(m) {
  m.innerHTML = `
    <div class="page-header">
      <div class="page-title">
        <h2>📊 Showroom Pulse</h2>
        <p>Live, audited business intelligence from actual transactions today.</p>
      </div>
      <div class="filter-group">
        <button class="filter-btn ${state.dashRange === 'today' ? 'active' : ''}" onclick="setDashRange('today')">Today</button>
        <button class="filter-btn ${state.dashRange === 'yesterday' ? 'active' : ''}" onclick="setDashRange('yesterday')">Yesterday</button>
        <button class="filter-btn ${state.dashRange === 'this_month' ? 'active' : ''}" onclick="setDashRange('this_month')">This Month</button>
      </div>
    </div>

    <!-- Quick Action Strip -->
    <div class="quick-action-strip">
      <button class="quick-action-btn" onclick="nav('pos')"><span>⚡</span> New POS Bill (F2)</button>
      <button class="quick-action-btn" onclick="nav('products')"><span>👗</span> Add Saree (F3)</button>
      <button class="quick-action-btn" onclick="nav('customers')"><span>💳</span> Collect Udhar</button>
      <button class="quick-action-btn" onclick="nav('purchase')"><span>🛒</span> New Purchase</button>
      <button class="quick-action-btn" onclick="nav('accounts')"><span>💸</span> Record Expense (F4)</button>
    </div>

    <div id="dash-content"><p style="color:#64748b">Loading dashboard metrics…</p></div>
  `;

  try {
    const d = await api(`/api/dashboard?range=${state.dashRange}`);
    
    // KPI Cards Definition
    const salesCards = [
      { t: `${state.dashRange === 'today' ? 'Today' : 'Total'} Sales`, v: inr(d.today_sales), icon: '💰', pg: 'sales', theme: 'theme-primary', sub: 'Gross billing' },
      { t: 'Cash Collected', v: inr(d.cash_sales), icon: '💵', pg: 'accounts', theme: 'theme-success', sub: 'Cash in counter' },
      { t: 'UPI / Digital', v: inr(d.upi_sales), icon: '📱', pg: 'sales', theme: 'theme-info', sub: 'PhonePe / GPay / QR' },
      { t: 'Card Swipes', v: inr(d.card_sales), icon: '💳', pg: 'sales', theme: 'theme-info', sub: 'POS machine' },
      { t: 'Udhar Given', v: inr(d.credit_sales), icon: '⏳', pg: 'reports', theme: 'theme-warning', sub: 'Credit balance' },
      { t: 'Advance Received', v: inr(d.advance_received), icon: '📥', pg: 'customers', theme: 'theme-gold', sub: 'Liability held' }
    ];

    const balanceCards = [
      { t: 'Total Customer Udhar', v: inr(d.total_udhar), icon: '👥', pg: 'reports', theme: 'theme-warning', sub: 'Khata receivables' },
      { t: 'Customer Advances Held', v: inr(d.total_advances), icon: '🤝', pg: 'customers', theme: 'theme-gold', sub: 'Customer credit' },
      { t: 'Supplier Outstanding', v: inr(d.total_supplier_outstanding), icon: '🏭', pg: 'purchases', theme: 'theme-danger', sub: 'Payables owed' },
      { t: 'Cash in Drawer', v: inr(d.cash_balance), icon: '🪙', pg: 'accounts', theme: 'theme-success', sub: 'Cash ledger' },
      { t: 'Bank Account Balance', v: inr(d.bank_balance), icon: '🏦', pg: 'accounts', theme: 'theme-info', sub: 'Bank & UPI ledger' },
      { t: 'Purchases Period', v: inr(d.purchases), icon: '📦', pg: 'purchases', theme: 'theme-neutral', sub: 'Stock purchased' },
      { t: 'Expenses Period', v: inr(d.expenses), icon: '💸', pg: 'accounts', theme: 'theme-danger', sub: 'Operating expenses' }
    ];

    const stockCards = [
      { t: 'Sarees in Stock', v: `${d.total_stock} pcs`, icon: '🥻', pg: 'products', theme: 'theme-primary', sub: 'Barcoded pieces' },
      { t: 'Stock MRP Value', v: inr(d.inventory_mrp), icon: '🏷️', pg: 'products', theme: 'theme-gold', sub: 'Retail value' },
      { t: 'Stock Cost Value', v: inr(d.inventory_cost), icon: '📊', pg: 'products', theme: 'theme-neutral', sub: 'Purchase cost' },
      { t: 'Low Stock Saree Alerts', v: d.low_stock, icon: '⚠️', pg: 'products', theme: d.low_stock > 0 ? 'theme-warning' : 'theme-neutral', sub: 'Stock ≤ 2 pieces' },
      { t: 'Out of Stock Sarees', v: d.out_of_stock, icon: '🚫', pg: 'products', theme: d.out_of_stock > 0 ? 'theme-danger' : 'theme-neutral', sub: '0 stock' },
      { t: 'Damaged Pieces', v: d.damaged, icon: '✂️', pg: 'products', theme: d.damaged > 0 ? 'theme-danger' : 'theme-neutral', sub: 'Unsaleable' }
    ];

    const renderCardsGrid = list => `
      <div class="cards">
        ${list.map(c => `
          <div class="card ${c.theme || ''}" onclick="nav('${c.pg}')">
            <div class="card-top">
              <span class="card-title">${c.t}</span>
              <div class="card-icon">${c.icon}</div>
            </div>
            <div class="card-val">${c.v}</div>
            <div class="card-sub">${c.sub}</div>
          </div>
        `).join('')}
      </div>
    `;

    // Category Sales Progress Bars
    const catTotal = (d.category_sales || []).reduce((acc, c) => acc + (c.total || 0), 0) || 1;
    const catBars = (d.category_sales || []).length ? d.category_sales.map(c => {
      const pct = Math.round(((c.total || 0) / catTotal) * 100);
      return `
        <div style="margin-bottom:12px">
          <div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:4px">
            <span style="font-weight:600">${esc(c.category || 'General')}</span>
            <span style="font-weight:700">${inr(c.total)} <span style="color:#64748b;font-weight:400">(${pct}%)</span></span>
          </div>
          <div style="background:#f1f5f9;height:8px;border-radius:4px;overflow:hidden">
            <div style="background:var(--primary);width:${pct}%;height:100%;border-radius:4px"></div>
          </div>
        </div>
      `;
    }).join('') : '<p style="color:#94a3b8;font-size:13px">No category sales recorded in this period.</p>';

    // Daily Sales Timeline
    const dailyItems = (d.daily_sales || []).length ? d.daily_sales.map(x => `
      <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:10px 14px;text-align:center;min-width:110px">
        <div style="font-size:11.5px;color:#64748b;margin-bottom:2px">${x.date}</div>
        <div style="font-size:15px;font-weight:700;color:var(--primary)">${inr(x.total)}</div>
      </div>
    `).join('') : '<p style="color:#94a3b8;font-size:13px">No daily sales in this range.</p>';

    $('#dash-content').innerHTML = `
      <div class="cards-section-title"><span>💵</span> Sales &amp; Revenue Flow (${state.dashRange})</div>
      ${renderCardsGrid(salesCards)}

      <div class="cards-section-title"><span>⚖️</span> Receivables, Payables &amp; Balances</div>
      ${renderCardsGrid(balanceCards)}

      <div class="cards-section-title"><span>👗</span> Showroom Inventory &amp; Stock Health</div>
      ${renderCardsGrid(stockCards)}

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:14px">
        <div class="panel" style="margin-top:0">
          <div class="panel-header">
            <div class="panel-title"><span>📈</span> Daily Sales Trends</div>
          </div>
          <div style="display:flex;gap:10px;overflow-x:auto;padding-bottom:8px">
            ${dailyItems}
          </div>
        </div>

        <div class="panel" style="margin-top:0">
          <div class="panel-header">
            <div class="panel-title"><span>🏷️</span> Category-Wise Sales</div>
          </div>
          <div>${catBars}</div>
        </div>
      </div>
    `;
  } catch (e) {
    $('#dash-content').innerHTML = `<p style="color:#ef4444">Failed to load dashboard: ${esc(e.message)}</p>`;
  }
}

function setDashRange(range) {
  state.dashRange = range;
  renderDashboard($('#main'));
}

// ==========================================
// 2. PRODUCT MASTER (SAREE INVENTORY)
// ==========================================
async function renderProducts(m) {
  m.innerHTML = `
    <div class="page-header">
      <div class="page-title">
        <h2>👗 Product Master &amp; Saree Inventory</h2>
        <p>Manage saree catalogs, attributes, pricing, and individual barcoded pieces.</p>
      </div>
      <button class="btn" onclick="toggleAddProductForm()">
        <span id="btn-toggle-prod-icon">➕</span> Add New Saree Catalog
      </button>
    </div>

    <!-- Collapsible Add Product Panel -->
    <div id="add-prod-panel" class="panel" style="display:none;margin-bottom:20px;border-top:3px solid var(--primary)">
      <div class="panel-header">
        <div class="panel-title"><span>✨</span> New Saree Product &amp; Barcode Creation</div>
        <button class="btn ghost sm" onclick="toggleAddProductForm()">Cancel</button>
      </div>
      
      <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));gap:14px">
        <div class="form-group">
          <label>Saree Name <span class="req">*</span></label>
          <input id="pn" placeholder="e.g. Kanjeevaram Silk Bridal Saree">
        </div>
        <div class="form-group">
          <label>SKU / Model No.</label>
          <input id="psku" placeholder="e.g. KANJ-001">
        </div>
        <div class="form-group">
          <label>Category <span class="req">*</span></label>
          <select id="pcat">
            ${state.cats.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Primary Colour</label>
          <input id="pcol" placeholder="e.g. Crimson Red">
        </div>
        <div class="form-group">
          <label>Fabric Material</label>
          <input id="pfab" placeholder="e.g. Pure Silk / Chiffon / Georgette">
        </div>
        <div class="form-group">
          <label>Design / Work Type</label>
          <input id="pdes" placeholder="e.g. Zari Buta / Floral Embroidery">
        </div>
        <div class="form-group">
          <label>Purchase Price (₹)</label>
          <input id="ppp" type="number" step="0.01" placeholder="Cost per piece">
        </div>
        <div class="form-group">
          <label>MRP (₹) <span class="req">*</span></label>
          <input id="pmrp" type="number" step="0.01" placeholder="Maximum retail price">
        </div>
        <div class="form-group">
          <label>Showroom Selling Price (₹) <span class="req">*</span></label>
          <input id="psp" type="number" step="0.01" placeholder="Final bill price">
        </div>
        <div class="form-group">
          <label>GST Rate (%)</label>
          <input id="pgst" type="number" value="5" step="0.1">
        </div>
        <div class="form-group">
          <label>Opening Stock (Pieces) <span class="req">*</span></label>
          <input id="pos" type="number" value="0" min="0" placeholder="Creates individual barcodes">
        </div>
        <div class="form-group">
          <label>Min Stock Alert Level</label>
          <input id="palert" type="number" value="2">
        </div>
      </div>

      <div style="margin-top:16px;display:flex;justify-content:flex-end;gap:10px">
        <button class="btn ghost" onclick="toggleAddProductForm()">Cancel</button>
        <button class="btn" onclick="addProduct()">
          <span>💾</span> Save Saree Product &amp; Generate Barcodes
        </button>
      </div>
    </div>

    <!-- Filter & Search Toolbar -->
    <div class="panel" style="margin-top:0">
      <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-bottom:16px">
        <div style="flex:1;min-width:260px" class="input-with-icon">
          <span class="input-icon">🔍</span>
          <input id="psearch" placeholder="Search saree by name, SKU, or category…" oninput="filterProducts()">
        </div>
        <div style="width:200px">
          <select id="pcat-filter" onchange="filterProducts()">
            <option value="">All Categories (${state.cats.length})</option>
            ${state.cats.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}
          </select>
        </div>
        <div style="width:180px">
          <select id="pstock-filter" onchange="filterProducts()">
            <option value="">All Stock Levels</option>
            <option value="in_stock">In Stock (> 0)</option>
            <option value="low_stock">Low Stock (≤ 2)</option>
            <option value="out_stock">Out of Stock (0)</option>
          </select>
        </div>
      </div>

      <div id="ptable"><p style="color:#64748b">Loading inventory…</p></div>
    </div>
  `;

  try {
    state.products = await api('/api/products');
    filterProducts();
  } catch (e) {
    $('#ptable').innerHTML = `<p style="color:#ef4444">Failed to load products: ${esc(e.message)}</p>`;
  }
}

function toggleAddProductForm() {
  const p = $('#add-prod-panel');
  if (!p) return;
  const isHidden = p.style.display === 'none';
  p.style.display = isHidden ? 'block' : 'none';
  if (isHidden) $('#pn').focus();
}

function filterProducts() {
  const q = ($('#psearch')?.value || '').toLowerCase().trim();
  const cat = $('#pcat-filter')?.value || '';
  const stockMode = $('#pstock-filter')?.value || '';

  let list = state.products || [];
  if (q) {
    list = list.filter(p => (
      (p.name || '') + ' ' + (p.sku || '') + ' ' + (p.category || '') + ' ' + (p.colour || '') + ' ' + (p.fabric || '')
    ).toLowerCase().includes(q));
  }
  if (cat) {
    list = list.filter(p => String(p.category_id) === String(cat));
  }
  if (stockMode === 'in_stock') {
    list = list.filter(p => p.current_stock > 0);
  } else if (stockMode === 'low_stock') {
    list = list.filter(p => p.current_stock > 0 && p.current_stock <= (p.min_stock_alert || 2));
  } else if (stockMode === 'out_stock') {
    list = list.filter(p => p.current_stock <= 0);
  }

  renderPTable(list);
}

function renderPTable(list) {
  const rows = list.map(pr => {
    let stockBadge = `<span class="badge badge-success">${pr.current_stock} in stock</span>`;
    if (pr.current_stock <= 0) {
      stockBadge = `<span class="badge badge-danger">Out of stock</span>`;
    } else if (pr.current_stock <= (pr.min_stock_alert || 2)) {
      stockBadge = `<span class="badge badge-warning">Low: ${pr.current_stock} left</span>`;
    }

    const nameCell = `
      <div>
        <b>${esc(pr.name)}</b>
        ${pr.sku ? `<div style="font-size:11.5px;color:#64748b">SKU: ${esc(pr.sku)}</div>` : ''}
      </div>
    `;

    const attrCell = `
      <div style="font-size:12px;color:#475569">
        ${pr.fabric ? `<span>${esc(pr.fabric)}</span>` : ''}
        ${pr.colour ? ` • <span>${esc(pr.colour)}</span>` : ''}
      </div>
    `;

    const actions = `
      <div style="display:flex;gap:6px">
        <button class="btn ghost sm" onclick="viewProductUnits(${pr.id}, '${esc(pr.name)}')">Barcodes (${pr.current_stock})</button>
      </div>
    `;

    return [
      nameCell,
      `<span class="badge badge-neutral">${esc(pr.category || 'General')}</span>`,
      attrCell,
      stockBadge,
      `<span style="color:#64748b;text-decoration:line-through">${inr(pr.mrp)}</span>`,
      `<b style="color:var(--primary)">${inr(pr.selling_price)}</b>`,
      actions
    ];
  });

  $('#ptable').innerHTML = table(
    ['Saree Product', 'Category', 'Attributes', 'Stock', 'MRP', 'Selling Price', 'Actions'],
    rows,
    [4, 5]
  );
}

async function addProduct() {
  const name = $('#pn').value.trim();
  if (!name) { toast('Please enter a Saree Product name.', 'warning'); $('#pn').focus(); return; }

  try {
    const body = {
      name,
      sku: $('#psku').value.trim() || undefined,
      category_id: +$('#pcat').value,
      colour: $('#pcol').value.trim(),
      fabric: $('#pfab').value.trim(),
      design_name: $('#pdes').value.trim(),
      purchase_price: +$('#ppp').value || 0,
      mrp: +$('#pmrp').value || 0,
      selling_price: +$('#psp').value || 0,
      gst_rate: +$('#pgst').value || 5,
      opening_stock: +$('#pos').value || 0,
      min_stock_alert: +$('#palert').value || 2
    };

    const r = await api('/api/products', 'POST', body);
    toast(`Saree product saved successfully. ${body.opening_stock} unique barcodes generated!`, 'success');
    toggleAddProductForm();
    state.products = await api('/api/products');
    filterProducts();
  } catch (e) {
    toast(e.message, 'error');
  }
}

async function viewProductUnits(pid, pname) {
  try {
    const units = await api(`/api/units`);
    const pUnits = units.filter(u => u.product_id === pid);

    const rows = pUnits.map(u => {
      let stBadge = `<span class="badge badge-success">${u.status}</span>`;
      if (u.status === 'Sold') stBadge = `<span class="badge badge-neutral">Sold</span>`;
      if (u.status === 'Returned') stBadge = `<span class="badge badge-warning">Returned</span>`;
      if (u.status === 'Damaged') stBadge = `<span class="badge badge-danger">Damaged</span>`;

      return [
        `<b>${esc(u.barcode)}</b>`,
        stBadge,
        u.date_sold || '—',
        `<button class="btn ghost sm" onclick="printSingleBarcode('${u.barcode}')">🖨️ Tag</button>`
      ];
    });

    const content = `
      <p style="font-size:13px;color:#64748b;margin-bottom:14px">Every piece has a unique barcode. Sold barcodes cannot be scanned or sold again.</p>
      ${table(['Barcode ID', 'Current Status', 'Sold Date', 'Print'], rows)}
    `;

    showModal(`👗 Barcoded Pieces — ${esc(pname)}`, content, `<button class="btn" onclick="closeModal()">Close</button>`, 'modal-lg');
  } catch (e) {
    toast(e.message, 'error');
  }
}

function printSingleBarcode(bc) {
  closeModal();
  nav('labels');
  setTimeout(() => {
    const el = $('#lbc');
    if (el) {
      el.value = bc;
      previewTag();
    }
  }, 200);
}

// ==========================================
// 3. POS BILLING SCREEN (RETAIL COUNTER)
// ==========================================
function renderPosBilling(m) {
  m.innerHTML = `
    <div class="page-header">
      <div class="page-title">
        <h2>🧾 POS Billing Counter</h2>
        <p>Scan saree barcodes, select customer, split payments, and generate tax invoices.</p>
      </div>
      <div style="display:flex;gap:8px">
        <button class="btn ghost sm" onclick="state.pos=[];renderPos();toast('Bill cleared.','info')">🗑️ Clear Bill</button>
      </div>
    </div>

    <div class="pos-layout">
      <!-- Left: Scanner & Billed Items -->
      <div>
        <div class="pos-scan-box">
          <label style="font-size:13.5px;color:var(--primary);font-weight:700;margin-bottom:8px">
            <span>📷 Scan Barcode or Type Code + Press Enter</span>
            <span style="font-size:11px;font-weight:normal;color:#64748b">Format: SR000100001</span>
          </label>
          <div style="display:flex;gap:8px">
            <input id="posbc" class="pos-scan-input" placeholder="Scan barcode here…" autocomplete="off" autofocus onkeydown="if(event.key==='Enter')addPosBarcode()">
            <button class="btn" style="padding:0 22px" onclick="addPosBarcode()">Scan</button>
          </div>
        </div>

        <div class="pos-items-card">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;padding-bottom:8px;border-bottom:1px solid #e2e8f0">
            <div style="font-size:14px;font-weight:700">Billed Sarees (<span id="pos-item-count">0</span>)</div>
            <div style="font-size:12px;color:#64748b">Individual Piece Tracking</div>
          </div>
          <div id="positems" style="flex:1"></div>
        </div>
      </div>

      <!-- Right: Customer, Discount & Payment -->
      <div>
        <div class="pos-summary-card">
          <!-- Customer Selection -->
          <div class="form-group" style="margin-bottom:14px">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
              <label style="margin:0">Customer Account</label>
              <a href="#" style="font-size:12px;color:var(--primary);font-weight:600" onclick="quickAddCustomerModal();return false">+ New Customer</a>
            </div>
            <select id="poscust" onchange="updatePosCustomerInfo()">
              <option value="">Walk-in Customer (Cash / Instant)</option>
              ${state.customers.map(c => `
                <option value="${c.id}" data-bal="${c.balance}" data-adv="${c.advance}" data-mob="${c.mobile}">
                  ${esc(c.name)} — ${c.mobile} ${c.balance > 0 ? `(Udhar ₹${c.balance})` : ''}
                </option>
              `).join('')}
            </select>
          </div>

          <!-- Customer Info Box (Hidden if walk-in) -->
          <div id="pos-cust-info" style="display:none;background:var(--surface-subtle);border:1px solid var(--border);border-radius:8px;padding:10px 12px;margin-bottom:14px;font-size:12px">
            <div style="display:flex;justify-content:space-between;margin-bottom:4px">
              <span id="pos-cust-phone"></span>
              <span id="pos-cust-type" class="badge badge-gold">Retail</span>
            </div>
            <div style="display:flex;justify-content:space-between;font-weight:600">
              <span id="pos-cust-udhar" style="color:var(--danger)">Udhar: ₹0</span>
              <span id="pos-cust-adv" style="color:var(--success)">Advance: ₹0</span>
            </div>
          </div>

          <div class="form-group" style="margin-bottom:12px">
            <label>Salesperson / Attendant</label>
            <input id="possp" placeholder="Staff Name (attendant record)">
          </div>

          <div class="form-group" style="margin-bottom:12px">
            <label>Bill Discount (₹)</label>
            <input id="posdisc" type="number" value="0" min="0" oninput="calcPosTotals()">
          </div>

          <!-- Total Bill Badge -->
          <div class="pos-total-display">
            <div class="total-label">Total Amount Payable</div>
            <div class="total-amount" id="pos-grand-total">₹0.00</div>
            <div style="font-size:11.5px;opacity:0.8" id="pos-subtotal-tax">Subtotal: ₹0.00 (Incl. 5% GST)</div>
          </div>

          <!-- Split Payment Modes -->
          <label style="margin-bottom:8px">Payment Split</label>
          <div class="pay-mode-row">
            <div class="pay-mode-label">💵 Cash</div>
            <input id="payCash" type="number" value="0" min="0" step="1" oninput="calcPosTotals()">
            <button class="btn-fill-pay" onclick="fillPayment('payCash')">Pay Full</button>
          </div>
          <div class="pay-mode-row">
            <div class="pay-mode-label">📱 UPI / QR</div>
            <input id="payUPI" type="number" value="0" min="0" step="1" oninput="calcPosTotals()">
            <button class="btn-fill-pay" onclick="fillPayment('payUPI')">Pay Full</button>
          </div>
          <div class="pay-mode-row">
            <div class="pay-mode-label">💳 Card</div>
            <input id="payCard" type="number" value="0" min="0" step="1" oninput="calcPosTotals()">
            <button class="btn-fill-pay" onclick="fillPayment('payCard')">Pay Full</button>
          </div>
          <div class="pay-mode-row">
            <div class="pay-mode-label">🏦 Bank</div>
            <input id="payBank" type="number" value="0" min="0" step="1" oninput="calcPosTotals()">
            <button class="btn-fill-pay" onclick="fillPayment('payBank')">Pay Full</button>
          </div>

          <!-- Live Balance / Udhar Alert -->
          <div id="pos-due-alert" class="pos-due-alert alert-paid" style="display:none"></div>

          <button class="btn lg" style="width:100%;margin-top:10px" onclick="doSale()">
            <span>🧾 Save &amp; Print Tax Invoice</span>
          </button>
        </div>
      </div>
    </div>
  `;

  renderPos();
  setTimeout(() => $('#posbc')?.focus(), 150);
}

function updatePosCustomerInfo() {
  const sel = $('#poscust');
  const opt = sel.options[sel.selectedIndex];
  const box = $('#pos-cust-info');

  if (!sel.value) {
    box.style.display = 'none';
    calcPosTotals();
    return;
  }

  box.style.display = 'block';
  $('#pos-cust-phone').textContent = `📱 ${opt.dataset.mob || 'No phone'}`;
  $('#pos-cust-udhar').textContent = `Udhar Due: ${inr(+opt.dataset.bal || 0)}`;
  $('#pos-cust-adv').textContent = `Advance Credit: ${inr(+opt.dataset.adv || 0)}`;
  calcPosTotals();
}

async function addPosBarcode() {
  const input = $('#posbc');
  const bc = input.value.trim().toUpperCase();
  if (!bc) return;

  // Check if already in bill
  if (state.pos.some(x => x.barcode.toUpperCase() === bc)) {
    toast(`Barcode ${bc} is already in the current bill!`, 'warning');
    input.value = '';
    return;
  }

  try {
    const u = await api(`/api/units?barcode=${encodeURIComponent(bc)}`);
    if (u.error || !u.id) throw new Error(`Barcode ${bc} not found in inventory.`);
    if (u.status !== 'Available') {
      throw new Error(`Saree ${bc} is '${u.status}' — cannot be sold again!`);
    }

    state.pos.push({
      unit_id: u.id,
      barcode: u.barcode,
      name: u.product,
      price: u.selling_price || 0,
      mrp: u.mrp || u.selling_price || 0
    });

    input.value = '';
    renderPos();
    toast(`Added: ${u.product} (${u.barcode})`, 'success');
  } catch (e) {
    toast(e.message, 'error');
  }
}

function renderPos() {
  const countEl = $('#pos-item-count');
  if (countEl) countEl.textContent = state.pos.length;

  const container = $('#positems');
  if (!container) return;

  if (!state.pos.length) {
    container.innerHTML = `
      <div style="text-align:center;padding:48px 20px;color:#94a3b8">
        <div style="font-size:36px;margin-bottom:8px">🥻</div>
        <p style="font-weight:600;color:#64748b">No sarees in this bill yet.</p>
        <p style="font-size:12px">Scan a saree barcode above to begin.</p>
      </div>
    `;
    calcPosTotals();
    return;
  }

  const rows = state.pos.map((x, i) => [
    `<b>${esc(x.name)}</b>`,
    `<span class="badge badge-gold">${esc(x.barcode)}</span>`,
    inr(x.price),
    `<button class="btn danger sm" onclick="state.pos.splice(${i},1);renderPos();toast('Item removed','info')">Remove</button>`
  ]);

  container.innerHTML = table(['Saree', 'Barcode', 'Price', 'Action'], rows, [2]);
  calcPosTotals();
}

function calcPosTotals() {
  const subtotal = state.pos.reduce((s, x) => s + (x.price || 0), 0);
  const discount = +($('#posdisc')?.value || 0);
  const grandTotal = Math.max(0, subtotal - discount);

  const pCash = +($('#payCash')?.value || 0);
  const pUPI = +($('#payUPI')?.value || 0);
  const pCard = +($('#payCard')?.value || 0);
  const pBank = +($('#payBank')?.value || 0);
  const totalPaid = pCash + pUPI + pCard + pBank;
  const balanceDue = Math.max(0, grandTotal - totalPaid);

  if ($('#pos-grand-total')) $('#pos-grand-total').textContent = inr(grandTotal);
  if ($('#pos-subtotal-tax')) {
    $('#pos-subtotal-tax').textContent = `Subtotal: ${inr(subtotal)} | Disc: ${inr(discount)}`;
  }

  const alertBox = $('#pos-due-alert');
  if (alertBox) {
    if (grandTotal === 0) {
      alertBox.style.display = 'none';
    } else if (balanceDue > 0.01) {
      alertBox.style.display = 'flex';
      alertBox.className = 'pos-due-alert alert-udhar';
      const custId = $('#poscust')?.value;
      alertBox.innerHTML = `
        <span>⏳ Unpaid: <b>${inr(balanceDue)}</b></span>
        <span>${custId ? 'Will be recorded as Udhar' : '<span style="color:red">⚠️ Select customer for Udhar</span>'}</span>
      `;
    } else {
      alertBox.style.display = 'flex';
      alertBox.className = 'pos-due-alert alert-paid';
      alertBox.innerHTML = `
        <span>✅ Fully Paid: <b>${inr(totalPaid)}</b></span>
        <span>Balance: ₹0.00</span>
      `;
    }
  }
}

function fillPayment(fieldId) {
  const subtotal = state.pos.reduce((s, x) => s + (x.price || 0), 0);
  const discount = +($('#posdisc')?.value || 0);
  const grandTotal = Math.max(0, subtotal - discount);

  // Clear all other payment fields
  ['payCash', 'payUPI', 'payCard', 'payBank'].forEach(id => {
    if (id !== fieldId && $(`#${id}`)) $(`#${id}`).value = 0;
  });

  const target = $(`#${fieldId}`);
  if (target) target.value = grandTotal;
  calcPosTotals();
}

async function doSale() {
  if (!state.pos.length) {
    toast('Cannot save empty bill. Scan at least one saree.', 'warning');
    return;
  }

  const subtotal = state.pos.reduce((s, x) => s + (x.price || 0), 0);
  const discount = +($('#posdisc')?.value || 0);
  const grandTotal = Math.max(0, subtotal - discount);

  const pays = [
    { mode: 'Cash', el: $('#payCash') },
    { mode: 'UPI', el: $('#payUPI') },
    { mode: 'Card', el: $('#payCard') },
    { mode: 'Bank Transfer', el: $('#payBank') }
  ].filter(p => +p.el?.value > 0).map(p => ({ mode: p.mode, amount: +p.el.value }));

  const totalPaid = pays.reduce((s, p) => s + p.amount, 0);
  const balanceDue = grandTotal - totalPaid;
  const custVal = $('#poscust')?.value;

  if (balanceDue > 0.01 && !custVal) {
    toast('Unpaid balance cannot be given to a Walk-in customer. Please select or add a Customer for Khata / Udhar.', 'error');
    $('#poscust')?.focus();
    return;
  }

  try {
    const payload = {
      customer_id: custVal ? +custVal : undefined,
      items: state.pos.map(x => ({ unit_id: x.unit_id, selling_price: x.price })),
      payments: pays,
      bill_discount: discount,
      request_id: 'sale-' + Date.now()
    };

    const r = await api('/api/sales', 'POST', payload);
    toast(`Invoice saved successfully: ${r.invoice_no}`, 'success');

    // Show printable invoice slip modal!
    const billedItems = [...state.pos];
    state.pos = [];
    renderPos();
    await loadBase();
    showInvoiceModal(r.id, r.invoice_no, billedItems, payload, grandTotal, totalPaid, balanceDue);
  } catch (e) {
    toast(e.message, 'error');
  }
}

function showInvoiceModal(invId, invNo, items, payload, grandTotal, totalPaid, balanceDue) {
  const showroom = state.settings.showroom_name || 'Saree Showroom';
  const gstin = state.settings.gstin || '';
  const phone = state.settings.phone || '';
  const address = state.settings.address || '';
  const cust = state.customers.find(c => c.id === payload.customer_id);

  const invoiceHTML = `
    <div id="print-area" class="printable-invoice">
      <div class="invoice-header">
        <div class="invoice-showroom-name">🥻 ${esc(showroom)}</div>
        <div style="font-size:12px;color:#555">${esc(address)} ${phone ? `• Phone: ${esc(phone)}` : ''}</div>
        ${gstin ? `<div style="font-size:11.5px;font-weight:700">GSTIN: ${esc(gstin)}</div>` : ''}
        <div style="font-size:13px;font-weight:700;margin-top:6px;text-transform:uppercase;letter-spacing:1px">TAX INVOICE</div>
      </div>

      <div class="invoice-meta-row">
        <div>
          <div><b>Invoice No:</b> ${esc(invNo)}</div>
          <div><b>Date:</b> ${new Date().toLocaleDateString('en-IN')} ${new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</div>
        </div>
        <div style="text-align:right">
          <div><b>Customer:</b> ${cust ? esc(cust.name) : 'Walk-in Customer'}</div>
          ${cust && cust.mobile ? `<div><b>Mobile:</b> ${esc(cust.mobile)}</div>` : ''}
        </div>
      </div>

      <table style="width:100%;border-collapse:collapse;margin:14px 0;font-size:12px">
        <thead>
          <tr style="border-bottom:1px solid #000;border-top:1px solid #000">
            <th style="padding:6px 4px;text-align:left">#</th>
            <th style="padding:6px 4px;text-align:left">Saree Item / Barcode</th>
            <th style="padding:6px 4px;text-align:right">Qty</th>
            <th style="padding:6px 4px;text-align:right">Rate</th>
            <th style="padding:6px 4px;text-align:right">Amount</th>
          </tr>
        </thead>
        <tbody>
          ${items.map((x, i) => `
            <tr>
              <td style="padding:6px 4px">${i + 1}</td>
              <td style="padding:6px 4px">${esc(x.name)}<br><small style="color:#555">${x.barcode}</small></td>
              <td style="padding:6px 4px;text-align:right">1</td>
              <td style="padding:6px 4px;text-align:right">${inr(x.price)}</td>
              <td style="padding:6px 4px;text-align:right">${inr(x.price)}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>

      <div style="display:flex;justify-content:flex-end;margin-top:10px">
        <div style="width:240px;font-size:12.5px">
          <div style="display:flex;justify-content:space-between;padding:3px 0">
            <span>Subtotal:</span> <span>${inr(items.reduce((s, x) => s + x.price, 0))}</span>
          </div>
          ${payload.bill_discount ? `
            <div style="display:flex;justify-content:space-between;padding:3px 0;color:red">
              <span>Discount:</span> <span>-${inr(payload.bill_discount)}</span>
            </div>
          ` : ''}
          <div style="display:flex;justify-content:space-between;padding:6px 0;border-top:1px solid #000;border-bottom:1px solid #000;font-weight:800;font-size:14px">
            <span>Grand Total:</span> <span>${inr(grandTotal)}</span>
          </div>
          <div style="display:flex;justify-content:space-between;padding:3px 0;margin-top:4px">
            <span>Amount Paid:</span> <span>${inr(totalPaid)}</span>
          </div>
          ${balanceDue > 0.01 ? `
            <div style="display:flex;justify-content:space-between;padding:3px 0;font-weight:700;color:red">
              <span>Balance Due (Udhar):</span> <span>${inr(balanceDue)}</span>
            </div>
          ` : ''}
        </div>
      </div>

      <div style="text-align:center;font-size:11px;margin-top:24px;border-top:1px dashed #ccc;padding-top:10px;color:#555">
        Thank you for your visit! Goods once sold can be exchanged within 7 days with original tag attached.
      </div>
    </div>
  `;

  const footer = `
    <button class="btn ghost" onclick="closeModal()">Close</button>
    <button class="btn" onclick="printInvoiceArea()">🖨️ Print Tax Invoice</button>
  `;

  showModal(`🧾 Invoice Created — ${esc(invNo)}`, invoiceHTML, footer, 'modal-lg');
}

function printInvoiceArea() {
  const content = $('#print-area')?.innerHTML;
  if (!content) return;
  const w = window.open('', '_blank');
  w.document.write(`
    <!doctype html>
    <html>
      <head>
        <title>Tax Invoice</title>
        <style>
          @page { size: auto; margin: 12mm; }
          body { font-family: -apple-system, system-ui, sans-serif; margin: 0; padding: 0; color: #000; }
          .printable-invoice { width: 100%; }
          table { width: 100%; border-collapse: collapse; }
        </style>
      </head>
      <body>${content}</body>
    </html>
  `);
  w.document.close();
  w.focus();
  setTimeout(() => { w.print(); }, 250);
}

// Quick Add Customer Modal
function quickAddCustomerModal() {
  const body = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="form-group" style="grid-column:1/-1">
        <label>Customer Full Name <span class="req">*</span></label>
        <input id="q-cname" placeholder="e.g. Smt. Sunita Sharma" autofocus>
      </div>
      <div class="form-group">
        <label>Mobile Number <span class="req">*</span></label>
        <input id="q-cmob" placeholder="10-digit mobile" maxlength="15">
      </div>
      <div class="form-group">
        <label>Customer Type</label>
        <select id="q-ctype">
          <option>Retail</option>
          <option>VIP</option>
          <option>Bridal</option>
          <option>Wholesale</option>
        </select>
      </div>
      <div class="form-group" style="grid-column:1/-1">
        <label>State (Decides CGST+SGST vs IGST)</label>
        <input id="q-cstate" value="${esc(state.settings.state || 'Delhi')}">
      </div>
    </div>
  `;

  const footer = `
    <button class="btn ghost" onclick="closeModal()">Cancel</button>
    <button class="btn" onclick="saveQuickCustomer()">Save &amp; Select Customer</button>
  `;

  showModal('👥 Quick Add New Customer', body, footer);
}

async function saveQuickCustomer() {
  const name = $('#q-cname').value.trim();
  const mob = $('#q-cmob').value.trim();
  if (!name || !mob) { toast('Customer Name and Mobile are required.', 'warning'); return; }

  try {
    const r = await api('/api/customers', 'POST', {
      name,
      mobile: mob,
      cust_type: $('#q-ctype').value,
      state: $('#q-cstate').value
    });

    toast('Customer added successfully!', 'success');
    await loadBase();
    closeModal();

    // Re-render POS with the new customer selected
    if (state.page === 'pos') {
      renderPosBilling($('#main'));
      setTimeout(() => {
        const sel = $('#poscust');
        if (sel) {
          sel.value = r.id;
          updatePosCustomerInfo();
        }
      }, 100);
    }
  } catch (e) {
    toast(e.message, 'error');
  }
}

// ==========================================
// 4. NEW PURCHASE
// ==========================================
async function renderNewPurchase(m) {
  if (!state.products.length) state.products = await api('/api/products');

  m.innerHTML = `
    <div class="page-header">
      <div class="page-title">
        <h2>🛒 New Purchase from Supplier</h2>
        <p>Purchased sarees are added to stock with new unique barcodes when saved.</p>
      </div>
    </div>

    <div class="panel" style="max-width:850px">
      <div class="panel-header">
        <div class="panel-title"><span>📦</span> Inward Saree Consignment</div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
        <div class="form-group">
          <label>Supplier / Weaver <span class="req">*</span></label>
          <select id="pusup">
            ${state.suppliers.map(s => `<option value="${s.id}">${esc(s.name)} (Bal ₹${s.balance})</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Supplier Invoice / Bill No.</label>
          <input id="pusinv" placeholder="e.g. INV-9842">
        </div>
        <div class="form-group" style="grid-column:1/-1">
          <label>Saree Product Catalog <span class="req">*</span></label>
          <select id="puprod">
            ${state.products.length ? state.products.map(pr => `
              <option value="${pr.id}">${esc(pr.name)} ${pr.sku ? `(${pr.sku})` : ''} — Current: ${pr.current_stock} pcs</option>
            `).join('') : '<option value="">No products available. Add a product first.</option>'}
          </select>
        </div>
        <div class="form-group">
          <label>Quantity (Pieces) <span class="req">*</span></label>
          <input id="puqty" type="number" value="10" min="1">
        </div>
        <div class="form-group">
          <label>Purchase Rate / Piece (₹) <span class="req">*</span></label>
          <input id="purate" type="number" step="0.01" placeholder="Cost per piece">
        </div>
        <div class="form-group">
          <label>Immediate Payment Amount (₹)</label>
          <input id="pupaid" type="number" value="0" min="0" step="0.01">
        </div>
        <div class="form-group">
          <label>Paid Via</label>
          <select id="pumode">
            <option>Cash</option>
            <option>UPI</option>
            <option>Bank Transfer</option>
          </select>
        </div>
      </div>

      <div style="margin-top:20px;display:flex;justify-content:flex-end;gap:10px">
        <button class="btn" onclick="doPurchase()">
          <span>💾</span> Save Purchase &amp; Create Individual Barcodes
        </button>
      </div>
    </div>
  `;
}

async function doPurchase() {
  const supId = $('#pusup')?.value;
  const prodId = $('#puprod')?.value;
  const qty = +$('#puqty')?.value || 0;
  const rate = +$('#purate')?.value || 0;
  const paid = +$('#pupaid')?.value || 0;

  if (!supId) { toast('Please select a supplier.', 'warning'); return; }
  if (!prodId) { toast('Please select a saree product.', 'warning'); return; }
  if (qty <= 0) { toast('Quantity must be at least 1 piece.', 'warning'); return; }
  if (rate <= 0) { toast('Purchase rate must be greater than 0.', 'warning'); return; }

  try {
    const r = await api('/api/purchases', 'POST', {
      supplier_id: +supId,
      supplier_invoice_no: $('#pusinv').value.trim(),
      items: [{ product_id: +prodId, qty, rate }],
      payments: paid > 0 ? [{ mode: $('#pumode').value, amount: paid }] : []
    });

    toast(`Purchase saved: ${r.purchase_no} — ${qty} barcoded pieces generated!`, 'success');
    await loadBase();
    nav('purchases');
  } catch (e) {
    toast(e.message, 'error');
  }
}

// ==========================================
// 5. PURCHASE REGISTER
// ==========================================
async function renderPurchaseRegister(m) {
  m.innerHTML = `
    <div class="page-header">
      <div class="page-title">
        <h2>📋 Purchase Register</h2>
        <p>Inward invoices from weavers and saree suppliers with payment tracking.</p>
      </div>
      <button class="btn" onclick="nav('purchase')">➕ New Purchase</button>
    </div>

    <div class="panel" style="margin-top:0">
      <div id="pu-table"><p style="color:#64748b">Loading purchase register…</p></div>
    </div>
  `;

  try {
    const rows = await api('/api/purchases');
    const tableRows = rows.map(r => {
      let st = `<span class="badge badge-success">Fully Paid</span>`;
      if (r.outstanding > 0.01) {
        st = `<span class="badge badge-warning">Due: ${inr(r.outstanding)}</span>`;
      }

      return [
        `<b>${esc(r.purchase_no)}</b>`,
        r.purchase_date,
        esc(r.supplier || 'Unknown Supplier'),
        inr(r.grand_total),
        inr(r.paid),
        inr(r.outstanding),
        st
      ];
    });

    $('#pu-table').innerHTML = table(
      ['Purchase No', 'Date', 'Supplier', 'Grand Total', 'Paid', 'Outstanding', 'Status'],
      tableRows,
      [3, 4, 5]
    );
  } catch (e) {
    $('#pu-table').innerHTML = `<p style="color:#ef4444">Failed to load purchases: ${esc(e.message)}</p>`;
  }
}

// ==========================================
// 6. SUPPLIERS & LEDGER
// ==========================================
async function renderSuppliers(m) {
  m.innerHTML = `
    <div class="page-header">
      <div class="page-title">
        <h2>🏭 Suppliers &amp; Ledger</h2>
        <p>Manage saree suppliers, payments, purchase returns, and running accounts.</p>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px">
      <!-- Record Payment -->
      <div class="panel" style="margin-top:0">
        <div class="panel-header">
          <div class="panel-title"><span>💳</span> Record Supplier Payment</div>
        </div>
        <div class="form-group" style="margin-bottom:12px">
          <label>Supplier <span class="req">*</span></label>
          <select id="spay">
            ${state.suppliers.map(s => `<option value="${s.id}">${esc(s.name)} — Owes ${inr(s.balance)}</option>`).join('')}
          </select>
        </div>
        <div class="form-group" style="margin-bottom:12px">
          <label>Payment Amount (₹) <span class="req">*</span></label>
          <input id="spamt" type="number" step="0.01" placeholder="Amount to pay">
        </div>
        <div class="form-group" style="margin-bottom:16px">
          <label>Payment Mode</label>
          <select id="spmode">
            <option>Cash</option>
            <option>UPI</option>
            <option>Bank Transfer</option>
          </select>
        </div>
        <button class="btn" onclick="doSupplierPayment()">Record Payment</button>
      </div>

      <!-- Purchase Return -->
      <div class="panel" style="margin-top:0">
        <div class="panel-header">
          <div class="panel-title"><span>↩️</span> Purchase Return (Damaged / Defect)</div>
        </div>
        <p style="font-size:12.5px;color:#64748b">Returns saree back to weaver. Stock falls and payable balance reduces automatically.</p>
        <div class="form-group" style="margin-bottom:12px">
          <label>Barcode of Defective Piece <span class="req">*</span></label>
          <input id="prbc" placeholder="e.g. SR000100001">
        </div>
        <div class="form-group" style="margin-bottom:16px">
          <label>Return Reason</label>
          <input id="prrea" placeholder="e.g. Weaving defect / torn border">
        </div>
        <button class="btn danger" onclick="doPurchaseReturn()">Return Piece to Supplier</button>
      </div>
    </div>

    <!-- Supplier Ledger Section -->
    <div class="panel">
      <div class="panel-header">
        <div class="panel-title"><span>📑</span> Supplier Running Ledger Statement</div>
        <div style="display:flex;gap:10px;align-items:center">
          <select id="sled" style="width:240px">
            ${state.suppliers.map(s => `<option value="${s.id}">${esc(s.name)}</option>`).join('')}
          </select>
          <button class="btn ghost sm" onclick="showSupplierLedger()">View Statement</button>
        </div>
      </div>
      <div id="sledout"><p style="color:#64748b;font-size:13px">Select a supplier above and click View Statement.</p></div>
    </div>
  `;
}

async function doSupplierPayment() {
  const supId = $('#spay')?.value;
  const amt = +$('#spamt')?.value || 0;
  if (!supId || amt <= 0) { toast('Please select supplier and enter valid amount.', 'warning'); return; }

  try {
    const r = await api('/api/supplier-payments', 'POST', {
      supplier_id: +supId,
      amount: amt,
      mode: $('#spmode').value
    });

    toast(`Supplier payment recorded! New balance owed: ${inr(r.balance)}`, 'success');
    await loadBase();
    renderSuppliers($('#main'));
  } catch (e) {
    toast(e.message, 'error');
  }
}

async function doPurchaseReturn() {
  const bc = $('#prbc')?.value.trim();
  if (!bc) { toast('Please enter barcode to return.', 'warning'); return; }

  try {
    const u = await api(`/api/units?barcode=${encodeURIComponent(bc)}`);
    if (u.error || !u.id) throw new Error(`Barcode ${bc} not found.`);
    if (u.status === 'Returned') throw new Error(`Barcode ${bc} is already returned.`);

    const r = await api('/api/purchase-returns', 'POST', {
      purchase_id: u.purchase_invoice_id,
      unit_id: u.id,
      reason: $('#prrea').value.trim() || 'Defective piece'
    });

    toast(`Piece returned to supplier. Balance reduced by ${inr(r.amount_returned)}!`, 'success');
    await loadBase();
    renderSuppliers($('#main'));
  } catch (e) {
    toast(e.message, 'error');
  }
}

async function showSupplierLedger() {
  const supId = $('#sled')?.value;
  if (!supId) return;

  try {
    const d = await api(`/api/supplier-ledger?supplier_id=${supId}`);
    const rows = d.rows.map(r => [
      r.date,
      `<b>${esc(r.voucher)}</b>`,
      esc(r.particulars),
      r.increase ? `<span style="color:var(--danger)">+${inr(r.increase)}</span>` : '—',
      r.decrease ? `<span style="color:var(--success)">-${inr(r.decrease)}</span>` : '—',
      `<b>${inr(r.running)}</b>`
    ]);

    $('#sledout').innerHTML = `
      <div style="background:var(--surface-subtle);padding:12px 16px;border-radius:8px;margin-bottom:14px;display:flex;justify-content:space-between;align-items:center">
        <div><b>${esc(d.supplier.name)}</b> — Ledger Statement</div>
        <div>Current Balance Owed: <b style="color:var(--danger);font-size:16px">${inr(d.balance)}</b></div>
      </div>
      ${table(['Date', 'Voucher', 'Particulars', 'Billed (+)', 'Paid / Returned (-)', 'Balance'], rows, [3, 4, 5])}
    `;
  } catch (e) {
    $('#sledout').innerHTML = `<p style="color:#ef4444">${esc(e.message)}</p>`;
  }
}

// ==========================================
// 7. CUSTOMERS & KHATA (UDHAR MANAGEMENT)
// ==========================================
async function renderCustomers(m) {
  m.innerHTML = `
    <div class="page-header">
      <div class="page-title">
        <h2>👥 Customers &amp; Khata (Udhar Management)</h2>
        <p>Customer ledger accounts, udhar collection, and advance receipts.</p>
      </div>
      <button class="btn" onclick="quickAddCustomerModal()">➕ Add New Customer</button>
    </div>

    <!-- Collection & Advance Actions -->
    <div class="panel" style="margin-top:0">
      <div class="panel-header">
        <div class="panel-title"><span>💵</span> Quick Collection / Advance Receipt</div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:12px">
        <div class="form-group">
          <label>Customer</label>
          <select id="cu">
            ${state.customers.map(c => `
              <option value="${c.id}">${esc(c.name)} — Udhar: ${inr(c.balance)}, Adv: ${inr(c.advance)}</option>
            `).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Amount (₹) <span class="req">*</span></label>
          <input id="camt" type="number" step="0.01" placeholder="Amount">
        </div>
        <div class="form-group">
          <label>Payment Mode</label>
          <select id="cmode">
            <option>Cash</option>
            <option>UPI</option>
            <option>Card</option>
            <option>Bank Transfer</option>
          </select>
        </div>
      </div>
      <div style="margin-top:14px;display:flex;gap:10px">
        <button class="btn success" onclick="collectUdhar()">Collect Udhar</button>
        <button class="btn gold" onclick="receiveAdvance()">Receive Advance (Liability)</button>
      </div>
    </div>

    <!-- Customer Directory Table -->
    <div class="panel">
      <div class="panel-header">
        <div class="panel-title"><span>📒</span> Customer Directory &amp; Balances</div>
      </div>
      <div id="cust-table"></div>
    </div>
  `;

  renderCustTable();
}

function renderCustTable() {
  const rows = state.customers.map(c => {
    let udharBadge = inr(c.balance);
    if (c.balance > 0) udharBadge = `<span class="badge badge-warning">${inr(c.balance)}</span>`;

    let advBadge = inr(c.advance);
    if (c.advance > 0) advBadge = `<span class="badge badge-success">${inr(c.advance)}</span>`;

    const nameCell = `<a href="#" onclick="showLedger(${c.id});return false" style="font-weight:700">${esc(c.name)}</a>`;

    return [
      nameCell,
      c.mobile || '—',
      `<span class="badge badge-neutral">${esc(c.cust_type || 'Retail')}</span>`,
      c.state || '—',
      udharBadge,
      advBadge,
      `<button class="btn ghost sm" onclick="showLedger(${c.id})">Khata Ledger</button>`
    ];
  });

  $('#cust-table').innerHTML = table(
    ['Customer Name', 'Mobile', 'Type', 'State', 'Udhar Balance', 'Advance Held', 'Action'],
    rows,
    [4, 5]
  );
}

async function collectUdhar() {
  const cid = $('#cu')?.value;
  const amt = +$('#camt')?.value || 0;
  if (!cid || amt <= 0) { toast('Please enter valid customer and amount.', 'warning'); return; }

  try {
    const r = await api('/api/collections', 'POST', {
      customer_id: +cid,
      amount: amt,
      mode: $('#cmode').value
    });

    toast(`Udhar collected! Receipt: ${r.receipt}`, 'success');
    await loadBase();
    renderCustomers($('#main'));
  } catch (e) {
    toast(e.message, 'error');
  }
}

async function receiveAdvance() {
  const cid = $('#cu')?.value;
  const amt = +$('#camt')?.value || 0;
  if (!cid || amt <= 0) { toast('Please enter valid customer and amount.', 'warning'); return; }

  try {
    await api('/api/advances', 'POST', {
      customer_id: +cid,
      amount: amt,
      mode: $('#cmode').value
    });

    toast('Advance received — recorded as liability (not sales revenue).', 'success');
    await loadBase();
    renderCustomers($('#main'));
  } catch (e) {
    toast(e.message, 'error');
  }
}

async function showLedger(cid) {
  try {
    const d = await api(`/api/ledger?customer_id=${cid}`);
    const cust = state.customers.find(c => c.id === cid) || {};

    const rows = d.rows.map(r => [
      r.txn_date,
      `<b>${esc(r.voucher)}</b>`,
      esc(r.particulars),
      r.debit ? `<span style="color:var(--danger)">${inr(r.debit)}</span>` : '—',
      r.credit ? `<span style="color:var(--success)">${inr(r.credit)}</span>` : '—',
      `<b>${inr(r.running)}</b>`
    ]);

    const content = `
      <div style="background:var(--surface-subtle);padding:14px;border-radius:8px;margin-bottom:14px;display:flex;justify-content:space-between;align-items:center">
        <div>
          <b style="font-size:15px">${esc(cust.name || 'Customer')}</b>
          <div style="font-size:12px;color:#64748b">Phone: ${cust.mobile || '—'} • ${cust.cust_type || 'Retail'}</div>
        </div>
        <div style="text-align:right">
          <div style="font-size:12px;color:#64748b">Khata Outstanding Balance</div>
          <div style="font-size:20px;font-weight:800;color:var(--danger)">${inr(d.balance)}</div>
        </div>
      </div>
      ${table(['Date', 'Voucher', 'Particulars', 'Debit (Purchase)', 'Credit (Payment)', 'Running Balance'], rows, [3, 4, 5])}
    `;

    showModal(`📒 Khata Ledger — ${esc(cust.name || 'Customer')}`, content, `<button class="btn" onclick="closeModal()">Close</button>`, 'modal-lg');
  } catch (e) {
    toast(e.message, 'error');
  }
}

// ==========================================
// 8. SALES REGISTER
// ==========================================
async function renderSalesRegister(m) {
  m.innerHTML = `
    <div class="page-header">
      <div class="page-title">
        <h2>📑 Sales Register</h2>
        <p>Complete historical log of retail tax invoices issued to customers.</p>
      </div>
      <button class="btn" onclick="nav('pos')">⚡ New Bill (POS)</button>
    </div>

    <div class="panel" style="margin-top:0">
      <div id="sales-table"><p style="color:#64748b">Loading sales…</p></div>
    </div>
  `;

  try {
    const rows = await api('/api/sales');
    const tableRows = rows.map(r => {
      let st = `<span class="badge badge-success">Paid</span>`;
      if (r.balance_due > 0.01) {
        st = `<span class="badge badge-warning">Udhar: ${inr(r.balance_due)}</span>`;
      }

      return [
        `<b>${esc(r.invoice_no)}</b>`,
        r.invoice_date,
        esc(r.customer || 'Walk-in Customer'),
        inr(r.grand_total),
        inr(r.received),
        inr(r.balance_due),
        st
      ];
    });

    $('#sales-table').innerHTML = table(
      ['Invoice No', 'Date', 'Customer', 'Grand Total', 'Received', 'Balance Due', 'Status'],
      tableRows,
      [3, 4, 5]
    );
  } catch (e) {
    $('#sales-table').innerHTML = `<p style="color:#ef4444">Failed to load sales: ${esc(e.message)}</p>`;
  }
}

// ==========================================
// 9. BARCODE & TAG STUDIO (BY EXACT SIZE)
// ==========================================
async function renderLabelsStudio(m) {
  m.innerHTML = `
    <div class="page-header">
      <div class="page-title">
        <h2>🏷️ Barcode &amp; Tag Studio</h2>
        <p>Customise tag layout by exact millimetres (25×15 mm, 50×30 mm, 75×50 mm) for thermal label printers.</p>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1.2fr 1fr;gap:20px;align-items:start">
      <!-- Left: Live Preview & Print -->
      <div class="panel" style="margin-top:0">
        <div class="panel-header">
          <div class="panel-title"><span>👁️</span> Live Tag Preview &amp; Print</div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
          <div class="form-group">
            <label>Tag Size Template</label>
            <select id="ltpl" onchange="previewTag()">
              ${state.templates.map(t => `<option value="${t.id}">${esc(t.name)} (${t.width_mm}×${t.height_mm} mm)</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label>Barcode to Print (Leave blank for sample)</label>
            <input id="lbc" placeholder="SR000100001" oninput="previewTag()">
          </div>
        </div>

        <div class="tag-preview-wrapper" id="tagprev">
          <p style="color:#64748b">Loading tag preview…</p>
        </div>

        <div style="margin-top:16px;display:flex;justify-content:flex-end;gap:10px">
          <button class="btn ghost" onclick="previewTag()">Refresh Preview</button>
          <button class="btn" onclick="printTag()">🖨️ Print to Thermal Printer</button>
        </div>
      </div>

      <!-- Right: Saved Templates & Creator -->
      <div>
        <div class="panel" style="margin-top:0;margin-bottom:18px">
          <div class="panel-header">
            <div class="panel-title"><span>📏</span> Saved Tag Sizes</div>
          </div>
          <div style="display:flex;flex-direction:column;gap:8px">
            ${state.templates.map(t => `
              <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 12px;background:var(--surface-subtle);border-radius:6px;font-size:12.5px">
                <div>
                  <b>${esc(t.name)}</b>
                  <div style="font-size:11px;color:#64748b">${JSON.parse(t.fields_json || '[]').join(', ')}</div>
                </div>
                <span class="badge badge-gold">${t.width_mm} × ${t.height_mm} mm</span>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Custom Tag Creator -->
        <div class="panel" style="margin-top:0">
          <div class="panel-header">
            <div class="panel-title"><span>✨</span> Create New Tag Size</div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
            <div class="form-group" style="grid-column:1/-1">
              <label>Template Name</label>
              <input id="tname" placeholder="e.g. Bridal Luxury Hang Tag 75x50">
            </div>
            <div class="form-group">
              <label>Width (mm)</label>
              <input id="tw" type="number" value="50">
            </div>
            <div class="form-group">
              <label>Height (mm)</label>
              <input id="th" type="number" value="30">
            </div>
            <div class="form-group" style="grid-column:1/-1">
              <label>Layout Style</label>
              <select id="tlay">
                <option value="standard">Standard</option>
                <option value="compact">Compact (Jewellery / Mini)</option>
                <option value="luxury">Luxury (Hang Tag)</option>
              </select>
            </div>
          </div>

          <label style="margin-bottom:6px">Fields on this tag:</label>
          <div id="tfields" style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:14px;font-size:12px">
            ${['showroom', 'product', 'sku', 'category', 'colour', 'fabric', 'design', 'mrp', 'selling_price', 'barcode'].map(f => `
              <label style="display:flex;align-items:center;gap:6px;font-weight:normal;margin:0">
                <input type="checkbox" value="${f}" ${['showroom', 'product', 'selling_price', 'barcode'].includes(f) ? 'checked' : ''}>
                ${f}
              </label>
            `).join('')}
          </div>

          <button class="btn sm" style="width:100%" onclick="addTemplate()">Save New Tag Template</button>
        </div>
      </div>
    </div>
  `;

  previewTag();
}

function tagHTML(tpl, unit) {
  const f = JSON.parse(tpl.fields_json || '[]');
  const scale = tpl.font_scale || 1;
  const showroom = state.settings.showroom_name || 'My Saree Showroom';

  const rows = {
    showroom: `<div style="font-size:${10 * scale}px;font-weight:800;letter-spacing:0.5px;text-transform:uppercase">${esc(showroom)}</div>`,
    product: `<div style="font-size:${11 * scale}px;font-weight:700;line-height:1.2;margin:2px 0">${esc(unit ? unit.product : 'Banarasi Silk Saree')}</div>`,
    sku: `<div style="font-size:${8.5 * scale}px;color:#444">SKU: ${esc(unit ? unit.sku : 'BAN-001')}</div>`,
    category: `<div style="font-size:${8.5 * scale}px;color:#444">${esc(unit ? unit.category : 'Banarasi Saree')}</div>`,
    colour: `<div style="font-size:${8.5 * scale}px;color:#444">Colour: ${esc(unit ? unit.colour : 'Red')}</div>`,
    fabric: `<div style="font-size:${8.5 * scale}px;color:#444">Fabric: ${esc(unit ? unit.fabric : 'Pure Silk')}</div>`,
    design: `<div style="font-size:${8.5 * scale}px;color:#444">${esc(unit ? unit.design : 'Zari Butidar')}</div>`,
    mrp: `<div style="font-size:${9.5 * scale}px;color:#666;text-decoration:line-through">MRP ${inrInt(unit ? unit.mrp : 6999)}</div>`,
    selling_price: `<div style="font-size:${12.5 * scale}px;font-weight:800;color:#000;margin:2px 0">${inrInt(unit ? unit.selling_price : 4999)}</div>`,
    barcode: `
      <div style="margin-top:2px">
        ${barcodeSVG(unit ? unit.barcode : 'SR000100001', Math.max(18, tpl.height_mm * 1.0))}
        <div style="font-size:${8 * scale}px;letter-spacing:2px;font-family:monospace;font-weight:700">${esc(unit ? unit.barcode : 'SR000100001')}</div>
      </div>
    `
  };

  return `
    <div class="tag" style="width:${tpl.width_mm}mm;height:${tpl.height_mm}mm;max-width:100%">
      ${f.map(k => rows[k] || '').join('')}
    </div>
  `;
}

async function previewTag() {
  const tplId = +$('#ltpl')?.value;
  const tpl = state.templates.find(t => t.id === tplId) || state.templates[0];
  if (!tpl) return;

  let unit = null;
  const bc = $('#lbc')?.value.trim();
  if (bc) {
    try {
      const u = await api(`/api/units?barcode=${encodeURIComponent(bc)}`);
      if (u && !u.error) {
        unit = {
          product: u.product,
          sku: u.sku || '',
          category: u.category || '',
          colour: u.colour || '',
          fabric: u.fabric || '',
          design: u.design || '',
          mrp: u.mrp,
          selling_price: u.selling_price,
          barcode: u.barcode
        };
      }
    } catch (_) {}
  }

  const container = $('#tagprev');
  if (container) {
    container.innerHTML = tagHTML(tpl, unit);
  }
}

function printTag() {
  const tplId = +$('#ltpl')?.value;
  const tpl = state.templates.find(t => t.id === tplId);
  if (!tpl) { toast('Please select a tag template.', 'warning'); return; }

  const html = $('#tagprev')?.innerHTML;
  if (!html) { toast('Nothing to print.', 'warning'); return; }

  const w = window.open('', '_blank');
  w.document.write(`
    <!doctype html>
    <html>
      <head>
        <title>Print Saree Barcode Tag</title>
        <style>
          @page { size: ${tpl.width_mm}mm ${tpl.height_mm}mm; margin: 0; }
          body { margin: 0; padding: 0; display: flex; align-items: center; justify-content: center; }
          .tag {
            width: ${tpl.width_mm}mm;
            height: ${tpl.height_mm}mm;
            border: none;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            overflow: hidden;
            box-sizing: border-box;
            padding: 2mm;
          }
        </style>
      </head>
      <body>${html}</body>
    </html>
  `);
  w.document.close();
  w.focus();
  setTimeout(() => { w.print(); }, 250);
}

async function addTemplate() {
  const name = $('#tname')?.value.trim();
  const width_mm = +$('#tw')?.value || 0;
  const height_mm = +$('#th')?.value || 0;
  if (!name || width_mm <= 0 || height_mm <= 0) {
    toast('Name, Width (mm), and Height (mm) are required.', 'warning');
    return;
  }

  const fields = $$('#tfields input:checked').map(i => i.value);

  try {
    await api('/api/label-templates', 'POST', {
      name,
      width_mm,
      height_mm,
      layout: $('#tlay').value,
      fields
    });

    toast(`Template '${name}' saved successfully!`, 'success');
    await loadBase();
    renderLabelsStudio($('#main'));
  } catch (e) {
    toast(e.message, 'error');
  }
}

// ==========================================
// 10. STOCK ADJUSTMENT & MOVEMENTS
// ==========================================
async function renderStockAdjustment(m) {
  if (!state.products.length) state.products = await api('/api/products');

  m.innerHTML = `
    <div class="page-header">
      <div class="page-title">
        <h2>📦 Stock Adjustment &amp; Movement Audit</h2>
        <p>Physical inventory count audits with mandatory reason logging.</p>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1.6fr;gap:20px;align-items:start">
      <!-- Adjustment Form -->
      <div class="panel" style="margin-top:0">
        <div class="panel-header">
          <div class="panel-title"><span>⚖️</span> Physical Count Adjustment</div>
        </div>
        <div class="form-group" style="margin-bottom:12px">
          <label>Product Catalog <span class="req">*</span></label>
          <select id="sprod">
            ${state.products.map(pr => `
              <option value="${pr.id}">${esc(pr.name)} — System Count: ${pr.current_stock} pcs</option>
            `).join('')}
          </select>
        </div>
        <div class="form-group" style="margin-bottom:12px">
          <label>Actual Physical Count <span class="req">*</span></label>
          <input id="sphy" type="number" min="0" placeholder="Actual pieces present in showroom">
        </div>
        <div class="form-group" style="margin-bottom:16px">
          <label>Mandatory Audit Reason <span class="req">*</span></label>
          <input id="srea" placeholder="e.g. Found damaged during physical audit">
        </div>
        <button class="btn" onclick="adjustStock()">Record Stock Adjustment</button>
      </div>

      <!-- Movement History -->
      <div class="panel" style="margin-top:0">
        <div class="panel-header">
          <div class="panel-title"><span>📜</span> Recent Stock Movements (In/Out)</div>
        </div>
        <div id="smove"><p style="color:#64748b">Loading stock history…</p></div>
      </div>
    </div>
  `;

  try {
    const r = await api('/api/stock-movements');
    const rows = r.slice(0, 50).map(x => {
      let typeBadge = `<span class="badge badge-success">${x.movement_type}</span>`;
      if (x.movement_type === 'OUT') typeBadge = `<span class="badge badge-danger">OUT</span>`;
      if (x.movement_type === 'ADJUST') typeBadge = `<span class="badge badge-warning">ADJUST</span>`;

      return [
        x.created_at ? x.created_at.slice(0, 16) : '—',
        `<b>${esc(x.product || '')}</b>`,
        x.barcode ? `<span class="badge badge-neutral">${x.barcode}</span>` : '—',
        typeBadge,
        `<b>${x.qty}</b>`,
        esc(x.reason || '—')
      ];
    });

    $('#smove').innerHTML = table(
      ['Time', 'Product', 'Barcode', 'Type', 'Qty', 'Reason'],
      rows,
      [4]
    );
  } catch (e) {
    $('#smove').innerHTML = `<p style="color:#ef4444">${esc(e.message)}</p>`;
  }
}

async function adjustStock() {
  const prodId = $('#sprod')?.value;
  const count = $('#sphy')?.value;
  const reason = $('#srea')?.value.trim();

  if (!prodId || count === '' || !reason) {
    toast('Product, physical count, and mandatory reason are required.', 'warning');
    return;
  }

  try {
    const r = await api('/api/stock-adjust', 'POST', {
      product_id: +prodId,
      physical_qty: +count,
      reason
    });

    toast(`Stock adjusted successfully (Diff: ${r.diff > 0 ? '+' : ''}${r.diff}). Movement audited!`, 'success');
    state.products = await api('/api/products');
    renderStockAdjustment($('#main'));
  } catch (e) {
    toast(e.message, 'error');
  }
}

// ==========================================
// 11. DAY BOOK & ACCOUNTS
// ==========================================
async function renderDayBook(m) {
  m.innerHTML = `
    <div class="page-header">
      <div class="page-title">
        <h2>💰 Day Book &amp; Cash/Bank Register</h2>
        <p>Daily cash drawer reconciliation, bank receipts, and operating expenses.</p>
      </div>
    </div>

    <!-- Record Expense Panel -->
    <div class="panel" style="margin-top:0;margin-bottom:18px">
      <div class="panel-header">
        <div class="panel-title"><span>💸</span> Record Showroom Expense</div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:12px">
        <div class="form-group">
          <label>Category</label>
          <select id="ecat">
            <option>Rent</option>
            <option>Electricity</option>
            <option>Staff Salary</option>
            <option>Tea &amp; Refreshments</option>
            <option>Packaging &amp; Carry Bags</option>
            <option>Transport &amp; Freight</option>
            <option>Marketing &amp; Ads</option>
            <option>Maintenance &amp; Repairs</option>
            <option>Internet &amp; Software</option>
            <option>Miscellaneous</option>
          </select>
        </div>
        <div class="form-group">
          <label>Amount (₹) <span class="req">*</span></label>
          <input id="eamt" type="number" step="0.01" placeholder="Expense amount">
        </div>
        <div class="form-group">
          <label>Payment Mode</label>
          <select id="emode">
            <option>Cash</option>
            <option>UPI</option>
            <option>Bank Transfer</option>
          </select>
        </div>
        <div class="form-group" style="grid-column:span 2">
          <label>Description / Note</label>
          <input id="edes" placeholder="e.g. November electricity bill payment">
        </div>
      </div>
      <div style="margin-top:14px;display:flex;justify-content:flex-end">
        <button class="btn" onclick="addExpense()">Record Expense</button>
      </div>
    </div>

    <!-- Day Book Tables -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px">
      <div class="panel" style="margin-top:0">
        <div class="panel-header">
          <div class="panel-title"><span>🪙</span> Cash Drawer Today</div>
        </div>
        <div id="cash-table">Loading…</div>
      </div>

      <div class="panel" style="margin-top:0">
        <div class="panel-header">
          <div class="panel-title"><span>🏦</span> Bank / UPI / Card Today</div>
        </div>
        <div id="bank-table">Loading…</div>
      </div>
    </div>
  `;

  try {
    const d = await api('/api/daybook');
    const cashRows = d.cash.map(x => [
      `<span class="badge ${x.txn_type === 'IN' ? 'badge-success' : 'badge-danger'}">${x.txn_type}</span>`,
      `<b>${inr(x.amount)}</b>`,
      esc(x.particulars)
    ]);

    const bankRows = d.bank.map(x => [
      `<span class="badge ${x.txn_type === 'IN' ? 'badge-success' : 'badge-danger'}">${x.txn_type}</span>`,
      `<span class="badge badge-neutral">${x.mode || 'Bank'}</span>`,
      `<b>${inr(x.amount)}</b>`,
      esc(x.particulars)
    ]);

    $('#cash-table').innerHTML = table(['Type', 'Amount', 'Particulars'], cashRows, [1]);
    $('#bank-table').innerHTML = table(['Type', 'Mode', 'Amount', 'Particulars'], bankRows, [2]);
  } catch (e) {
    $('#cash-table').innerHTML = `<p style="color:#ef4444">${esc(e.message)}</p>`;
  }
}

async function addExpense() {
  const amt = +$('#eamt')?.value || 0;
  if (amt <= 0) { toast('Please enter a valid expense amount.', 'warning'); return; }

  try {
    await api('/api/expenses', 'POST', {
      category: $('#ecat').value,
      amount: amt,
      mode: $('#emode').value,
      description: $('#edes').value.trim()
    });

    toast('Expense recorded successfully.', 'success');
    renderDayBook($('#main'));
  } catch (e) {
    toast(e.message, 'error');
  }
}

// ==========================================
// 12. REPORTS & UDHAR AGEING
// ==========================================
async function renderReports(m) {
  m.innerHTML = `
    <div class="page-header">
      <div class="page-title">
        <h2>📈 Financial Reports &amp; Udhar Ageing</h2>
        <p>Outstanding khata dues grouped by ageing brackets with audit logs.</p>
      </div>
    </div>

    <div class="panel" style="margin-top:0">
      <div class="panel-header">
        <div class="panel-title"><span>⏳</span> Customer Udhar Ageing Analysis</div>
      </div>
      <div id="ageing-table"><p style="color:#64748b">Loading ageing data…</p></div>
    </div>

    <div class="panel">
      <div class="panel-header">
        <div class="panel-title"><span>🛡️</span> Security &amp; Mutation Audit Trail</div>
      </div>
      <div id="audit-table"><p style="color:#64748b">Loading audit trail…</p></div>
    </div>
  `;

  try {
    const a = await api('/api/ageing');
    const ageingRows = a.map(x => {
      let bClass = 'badge-success';
      if (x.bucket === '31-60') bClass = 'badge-warning';
      if (x.bucket === '61-90' || x.bucket === '90+') bClass = 'badge-danger';

      return [
        `<b>${esc(x.invoice_no)}</b>`,
        x.customer_id,
        x.date,
        `${x.days} days`,
        `<span class="badge ${bClass}">${x.bucket} days</span>`,
        `<b style="color:var(--danger)">${inr(x.due)}</b>`
      ];
    });

    $('#ageing-table').innerHTML = table(
      ['Invoice', 'Customer ID', 'Invoice Date', 'Elapsed', 'Ageing Bucket', 'Due Amount'],
      ageingRows,
      [5]
    );

    const logs = await api('/api/audit');
    const logRows = logs.slice(0, 30).map(x => [
      `<span class="badge badge-neutral">${esc(x.module)}</span>`,
      `<b>${esc(x.action)}</b>`,
      x.created_at ? x.created_at.slice(0, 19) : '—'
    ]);

    $('#audit-table').innerHTML = table(['Module', 'Action', 'Timestamp'], logRows);
  } catch (e) {
    $('#ageing-table').innerHTML = `<p style="color:#ef4444">${esc(e.message)}</p>`;
  }
}

// ==========================================
// 13. SETTINGS & GOOGLE DRIVE CLOUD BACKUP
// ==========================================
async function renderSettings(m) {
  m.innerHTML = `<p style="color:#64748b">Loading settings…</p>`;

  try {
    const s = await api('/api/settings');
    state.settings = s;

    m.innerHTML = `
      <div class="page-header">
        <div class="page-title">
          <h2>⚙️ Company Settings &amp; Google Drive Backup</h2>
          <p>Showroom tax details, automatic updates, and tamper-proof cloud backup.</p>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1.2fr 1fr;gap:20px;align-items:start">
        <!-- Left: Showroom Profile & Auto-Update -->
        <div>
          <div class="panel" style="margin-top:0;margin-bottom:18px">
            <div class="panel-header">
              <div class="panel-title"><span>🏢</span> Showroom &amp; GST Details</div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
              <div class="form-group" style="grid-column:1/-1">
                <label>Showroom Name</label>
                <input id="sname" value="${esc(s.showroom_name || '')}">
              </div>
              <div class="form-group">
                <label>Contact Phone</label>
                <input id="sphone" value="${esc(s.phone || '')}">
              </div>
              <div class="form-group">
                <label>GSTIN</label>
                <input id="sgstin" value="${esc(s.gstin || '')}">
              </div>
              <div class="form-group">
                <label>State (Calculates CGST/SGST vs IGST)</label>
                <input id="sstate" value="${esc(s.state || '')}">
              </div>
              <div class="form-group">
                <label>Invoice Prefix</label>
                <input id="sinv" value="${esc(s.invoice_prefix || '')}">
              </div>
              <div class="form-group" style="grid-column:1/-1">
                <label>Default GST Mode</label>
                <select id="sgmode">
                  <option ${s.default_gst_mode === 'inclusive' ? 'selected' : ''}>inclusive</option>
                  <option ${s.default_gst_mode === 'exclusive' ? 'selected' : ''}>exclusive</option>
                </select>
              </div>
            </div>
          </div>

          <div class="panel" style="margin-top:0">
            <div class="panel-header">
              <div class="panel-title"><span>🔄</span> Auto-Update Configuration</div>
            </div>
            <p style="font-size:12px;color:#64748b">Verified updates are downloaded in the background and applied safely on next launch.</p>
            <div class="form-group" style="margin-bottom:12px">
              <label>Auto-Update Mode</label>
              <select id="supd">
                <option value="install_on_restart" ${s.auto_update_mode === 'install_on_restart' ? 'selected' : ''}>install_on_restart (Recommended)</option>
                <option value="notify_only" ${s.auto_update_mode === 'notify_only' ? 'selected' : ''}>notify_only</option>
                <option value="off" ${s.auto_update_mode === 'off' ? 'selected' : ''}>off</option>
              </select>
            </div>
            <div class="form-group" style="margin-bottom:12px">
              <label>Update Channel URL</label>
              <input id="sch" value="${esc(s.update_channel_url || '')}">
            </div>
            <div style="display:flex;gap:8px">
              <button class="btn ghost sm" onclick="checkUpd()">Check for Updates Now</button>
            </div>
            <div id="upd" style="margin-top:10px"></div>
          </div>
        </div>

        <!-- Right: Google Drive Backup & Restore -->
        <div>
          <div class="panel" style="margin-top:0;border-top:3px solid var(--gold)">
            <div class="panel-header">
              <div class="panel-title"><span>☁️</span> Google Drive Cloud Backup</div>
            </div>
            <p style="font-size:12.5px;color:#475569;line-height:1.4">
              Works seamlessly with your Gmail Google Drive account. Install <b>Google Drive for Desktop</b>, sign in, and point your backup folder below.
            </p>

            <div class="form-group" style="margin-bottom:12px">
              <label>Google Drive Backup Folder on PC</label>
              <input id="sdrive" value="${esc(s.drive_backup_folder || '')}" placeholder="C:\\Users\\Name\\Google Drive\\Saree ERP Backups">
            </div>

            <div class="form-group" style="margin-bottom:16px">
              <label>Auto-Copy Every Backup to Drive</label>
              <select id="sdrvauto">
                <option value="1" ${s.drive_auto_backup ? 'selected' : ''}>Yes (Auto-sync to cloud)</option>
                <option value="0" ${!s.drive_auto_backup ? 'selected' : ''}>No</option>
              </select>
            </div>

            <div style="display:flex;flex-direction:column;gap:8px">
              <button class="btn gold" onclick="backupDrive()">☁️ Backup to Google Drive Now</button>
              <button class="btn ghost" onclick="backupLocal()">💾 Backup Local Database Now</button>
              <button class="btn ghost" onclick="listBackups()">📂 View Backups &amp; Restore</button>
            </div>

            <div id="bklist" style="margin-top:14px"></div>
          </div>

          <div style="margin-top:16px;display:flex;justify-content:flex-end">
            <button class="btn lg" style="width:100%" onclick="saveSettings()">💾 Save All Settings</button>
          </div>
        </div>
      </div>
    `;
  } catch (e) {
    m.innerHTML = `<p style="color:#ef4444">Failed to load settings: ${esc(e.message)}</p>`;
  }
}

async function saveSettings() {
  try {
    await api('/api/settings', 'POST', {
      showroom_name: $('#sname').value.trim(),
      phone: $('#sphone').value.trim(),
      gstin: $('#sgstin').value.trim(),
      state: $('#sstate').value.trim(),
      invoice_prefix: $('#sinv').value.trim(),
      default_gst_mode: $('#sgmode').value,
      auto_update_mode: $('#supd').value,
      update_channel_url: $('#sch').value.trim(),
      drive_backup_folder: $('#sdrive').value.trim(),
      drive_auto_backup: $('#sdrvauto').value === '1'
    });

    toast('Settings saved successfully!', 'success');
    await loadBase();
  } catch (e) {
    toast(e.message, 'error');
  }
}

async function checkUpd() {
  try {
    const r = await api('/api/update/check');
    $('#upd').innerHTML = `
      <div style="background:var(--surface-subtle);padding:10px 12px;border-radius:6px;font-size:12px;margin-top:8px">
        <div>Current Version: <b>${r.current}</b> | Latest: <b>${r.latest || '—'}</b></div>
        <div>Update Available: <b>${r.available ? 'Yes (will install on next launch)' : 'No'}</b></div>
        ${r.note ? `<div style="color:#64748b;margin-top:4px">${esc(r.note)}</div>` : ''}
      </div>
    `;
  } catch (e) {
    toast(e.message, 'error');
  }
}

async function backupLocal() {
  try {
    const r = await api('/api/backup', 'POST', {});
    toast(`Local backup saved: ${r.file}`, 'success');
  } catch (e) {
    toast(e.message, 'error');
  }
}

async function backupDrive() {
  try {
    const r = await api('/api/backup/drive', 'POST', {});
    toast(`Backed up to Google Drive folder: ${r.drive_file}`, 'success');
  } catch (e) {
    toast(e.message, 'error');
  }
}

async function listBackups() {
  try {
    const d = await api('/api/backups');
    const rows = d.all.map(r => [
      `<b>${esc(r.file)}</b>`,
      `<span class="badge ${r.source === 'drive' ? 'badge-gold' : 'badge-neutral'}">${r.source}</span>`,
      `${Math.round(r.size / 1024)} KB`,
      `<button class="btn ghost sm" onclick="stageRestore('${esc(r.file)}')">Restore</button>`
    ]);

    $('#bklist').innerHTML = `
      <div style="margin-top:12px;border-top:1px solid #e2e8f0;padding-top:12px">
        <div style="font-weight:700;font-size:13px;margin-bottom:8px">Available Backup Snapshots</div>
        ${table(['Backup File', 'Location', 'Size', 'Action'], rows)}
      </div>
    `;
  } catch (e) {
    toast(e.message, 'error');
  }
}

async function stageRestore(filename) {
  if (!confirm(`Are you sure you want to restore from ${filename}?\n\nYour current database will be saved first as a pre-restore backup, and this snapshot will be restored when the application is reopened.`)) {
    return;
  }

  try {
    const r = await api('/api/restore/prepare', 'POST', { filename, source: 'local' });
    toast(r.note, 'info');
  } catch (e) {
    toast(e.message, 'error');
  }
}

// --- Initialization ---
startClock();
loadBase().then(() => render());

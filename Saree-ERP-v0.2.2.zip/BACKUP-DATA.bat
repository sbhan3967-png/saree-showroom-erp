@echo off
REM Backs up your database before you update or move the app.
REM Copy: data\saree.db -> data\backups\saree-backup-YYYYMMDD-HHMMSS.db
cd /d "%~dp0"
if not exist "data\backups" mkdir "data\backups"
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set DT=%%I
set STAMP=%DT:~0,8%-%DT:~8,6%
if exist "data\saree.db" (
  copy "data\saree.db" "data\backups\saree-backup-%STAMP%.db"
  echo Backed up to data\backups\saree-backup-%STAMP%.db
) else (
  echo No data\saree.db yet - first run will create an empty database.
)
pause

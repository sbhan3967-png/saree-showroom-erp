"""Saree ERP — SQLite schema. Single-showroom, owner-controlled, no user roles.

Design rules (from the brief):
- Ledgers are DERIVED from immutable transaction rows, never hand-edited.
- Stock never goes negative without an explicit exception flag.
- A sold barcode cannot be sold again unless it legitimately returned.
- Every financial mutation is one DB transaction + a balanced journal + audit row.
- data/ (the .db file) is NEVER touched by the auto-updater.
"""
from __future__ import annotations
import sqlite3, json, os
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("SAREE_ERP_DATA_DIR", str(APP_ROOT / "data")))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "saree.db"
BACKUP_DIR = DATA_DIR / "backups"
BACKUP_DIR.mkdir(parents=True, exist_ok=True)

DEFAULT_CATEGORIES = [
    "Banarasi Saree", "Kanjivaram Saree", "Silk Saree", "Cotton Saree",
    "Chiffon Saree", "Georgette Saree", "Organza Saree", "Designer Saree",
    "Bridal Saree", "Wedding Saree", "Party Wear Saree", "Printed Saree",
    "Linen Saree", "Tussar Saree", "Paithani Saree", "Chanderi Saree",
    "Daily Wear Saree", "Embroidered Saree", "Fancy Saree", "Net Saree",
    "Tissue Saree", "Maheshwari Saree", "Bandhani Saree",
]

CHART = [
    ("Cash", "asset"), ("Bank", "asset"), ("Sales", "income"),
    ("Sales Returns", "income"), ("Purchases", "expense"),
    ("Purchase Returns", "expense"), ("Customer Receivables", "asset"),
    ("Supplier Payables", "liability"), ("Customer Advances", "liability"),
    ("GST Input", "asset"), ("GST Output", "liability"),
    ("Expenses", "expense"), ("Capital", "equity"), ("Inventory", "asset"),
    ("Discounts", "expense"), ("Other Income", "income"),
]

SCHEMA = """
CREATE TABLE IF NOT EXISTS app_meta (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS company_settings (
  id INTEGER PRIMARY KEY CHECK(id=1), showroom_name TEXT DEFAULT 'My Saree Showroom',
  address TEXT DEFAULT '', phone TEXT DEFAULT '', whatsapp TEXT DEFAULT '',
  email TEXT DEFAULT '', website TEXT DEFAULT '', gstin TEXT DEFAULT '',
  pan TEXT DEFAULT '', state TEXT DEFAULT 'Delhi', pincode TEXT DEFAULT '',
  tagline TEXT DEFAULT '', currency TEXT DEFAULT 'INR',
  invoice_prefix TEXT DEFAULT 'INV', financial_year TEXT DEFAULT '2026-27',
  default_gst_mode TEXT DEFAULT 'inclusive', default_payment TEXT DEFAULT 'Cash',
  gst_rate_default REAL DEFAULT 5, allow_negative_stock INTEGER DEFAULT 0,
  low_stock_threshold INTEGER DEFAULT 2, auto_update_mode TEXT DEFAULT 'install_on_restart',
  update_channel_url TEXT DEFAULT 'https://raw.githubusercontent.com/sbhan3967-png/saree-showroom-erp/main/version.json', logo_path TEXT DEFAULT '',
  drive_backup_folder TEXT DEFAULT '', drive_auto_backup INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, parent_id INTEGER, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS suppliers (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, contact_person TEXT DEFAULT '',
  mobile TEXT DEFAULT '', whatsapp TEXT DEFAULT '', email TEXT DEFAULT '', address TEXT DEFAULT '',
  gstin TEXT DEFAULT '', state TEXT DEFAULT '', opening_balance REAL DEFAULT 0,
  credit_limit REAL DEFAULT 0, payment_terms TEXT DEFAULT '', notes TEXT DEFAULT '', active INTEGER DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now','localtime')));
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, mobile TEXT UNIQUE NOT NULL,
  alt_mobile TEXT DEFAULT '', whatsapp TEXT DEFAULT '', email TEXT DEFAULT '', address TEXT DEFAULT '',
  city TEXT DEFAULT '', state TEXT DEFAULT '', pincode TEXT DEFAULT '', gstin TEXT DEFAULT '',
  dob TEXT DEFAULT '', anniversary TEXT DEFAULT '', category TEXT DEFAULT 'Regular',
  cust_type TEXT DEFAULT 'Retail', opening_balance REAL DEFAULT 0,
  credit_limit REAL DEFAULT 0, credit_period_days INTEGER DEFAULT 30,
  notes TEXT DEFAULT '', created_at TEXT DEFAULT (datetime('now','localtime')));
CREATE TABLE IF NOT EXISTS employees (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, mobile TEXT DEFAULT '',
  address TEXT DEFAULT '', joining_date TEXT DEFAULT '', salary REAL DEFAULT 0,
  designation TEXT DEFAULT 'Salesperson', department TEXT DEFAULT 'Sales', status TEXT DEFAULT 'Active');
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, saree_code TEXT DEFAULT '',
  sku TEXT UNIQUE, category_id INTEGER, subcategory TEXT DEFAULT '', brand TEXT DEFAULT '',
  manufacturer TEXT DEFAULT '', supplier_id INTEGER, fabric TEXT DEFAULT '', saree_type TEXT DEFAULT '',
  collection TEXT DEFAULT '', design_name TEXT DEFAULT '', design_number TEXT DEFAULT '',
  colour TEXT DEFAULT '', secondary_colour TEXT DEFAULT '', pattern TEXT DEFAULT '',
  border_type TEXT DEFAULT '', work_type TEXT DEFAULT '', occasion TEXT DEFAULT '',
  style TEXT DEFAULT '', length TEXT DEFAULT '', width TEXT DEFAULT '', weight REAL DEFAULT 0,
  blouse_available INTEGER DEFAULT 1, blouse_details TEXT DEFAULT '',
  purchase_price REAL DEFAULT 0, mrp REAL DEFAULT 0, selling_price REAL DEFAULT 0,
  wholesale_price REAL DEFAULT 0, min_selling_price REAL DEFAULT 0, discount_limit_pct REAL DEFAULT 0,
  gst_rate REAL DEFAULT 5, hsn TEXT DEFAULT '6308', rack TEXT DEFAULT '', shelf TEXT DEFAULT '',
  location TEXT DEFAULT '', purchase_date TEXT DEFAULT '', stock_entry_date TEXT DEFAULT '',
  image_path TEXT DEFAULT '', description TEXT DEFAULT '', opening_stock INTEGER DEFAULT 0,
  current_stock INTEGER DEFAULT 0, min_stock_alert INTEGER DEFAULT 2, status TEXT DEFAULT 'Active',
  created_at TEXT DEFAULT (datetime('now','localtime')),
  FOREIGN KEY(category_id) REFERENCES categories(id), FOREIGN KEY(supplier_id) REFERENCES suppliers(id));
CREATE TABLE IF NOT EXISTS product_units (
  id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL, barcode TEXT UNIQUE NOT NULL,
  purchase_invoice_id INTEGER, purchase_price REAL DEFAULT 0, status TEXT DEFAULT 'Available',
  location TEXT DEFAULT '', date_added TEXT DEFAULT (date('now','localtime')),
  date_sold TEXT DEFAULT '', sales_invoice_id INTEGER, return_history TEXT DEFAULT '[]',
  FOREIGN KEY(product_id) REFERENCES products(id));
CREATE TABLE IF NOT EXISTS stock_movements (
  id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, unit_id INTEGER, barcode TEXT DEFAULT '',
  movement_type TEXT NOT NULL, qty INTEGER NOT NULL, ref_type TEXT DEFAULT '', ref_id INTEGER,
  reason TEXT DEFAULT '', created_at TEXT DEFAULT (datetime('now','localtime')));
CREATE TABLE IF NOT EXISTS stock_adjustments (
  id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, system_qty INTEGER, physical_qty INTEGER,
  diff INTEGER, reason TEXT NOT NULL, created_at TEXT DEFAULT (datetime('now','localtime')));
CREATE TABLE IF NOT EXISTS purchase_invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_no TEXT UNIQUE, supplier_invoice_no TEXT DEFAULT '',
  supplier_id INTEGER, purchase_date TEXT DEFAULT (date('now','localtime')), due_date TEXT DEFAULT '',
  subtotal REAL DEFAULT 0, discount REAL DEFAULT 0, taxable REAL DEFAULT 0, cgst REAL DEFAULT 0,
  sgst REAL DEFAULT 0, igst REAL DEFAULT 0, transport REAL DEFAULT 0, packaging REAL DEFAULT 0,
  other_charges REAL DEFAULT 0, round_off REAL DEFAULT 0, grand_total REAL DEFAULT 0,
  paid REAL DEFAULT 0, outstanding REAL DEFAULT 0, payment_mode TEXT DEFAULT '',
  notes TEXT DEFAULT '', status TEXT DEFAULT 'Posted', request_id TEXT UNIQUE,
  created_at TEXT DEFAULT (datetime('now','localtime')));
CREATE TABLE IF NOT EXISTS purchase_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_id INTEGER NOT NULL, product_id INTEGER,
  qty INTEGER NOT NULL, rate REAL DEFAULT 0, discount REAL DEFAULT 0, taxable REAL DEFAULT 0,
  gst_rate REAL DEFAULT 5, cgst REAL DEFAULT 0, sgst REAL DEFAULT 0, igst REAL DEFAULT 0, amount REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS purchase_payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_id INTEGER, supplier_id INTEGER,
  amount REAL NOT NULL, mode TEXT DEFAULT 'Cash', pay_date TEXT DEFAULT (date('now','localtime')), notes TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS purchase_returns (
  id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_id INTEGER, product_id INTEGER, unit_id INTEGER,
  qty INTEGER DEFAULT 1, amount REAL DEFAULT 0, reason TEXT DEFAULT '', return_date TEXT DEFAULT (date('now','localtime')));
CREATE TABLE IF NOT EXISTS sales_invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT UNIQUE, invoice_date TEXT DEFAULT (date('now','localtime')),
  invoice_time TEXT DEFAULT (time('now','localtime')), customer_id INTEGER, salesperson_id INTEGER,
  subtotal REAL DEFAULT 0, product_discount REAL DEFAULT 0, bill_discount REAL DEFAULT 0,
  taxable REAL DEFAULT 0, cgst REAL DEFAULT 0, sgst REAL DEFAULT 0, igst REAL DEFAULT 0,
  charges REAL DEFAULT 0, round_off REAL DEFAULT 0, grand_total REAL DEFAULT 0,
  received REAL DEFAULT 0, previous_outstanding REAL DEFAULT 0, advance_adjusted REAL DEFAULT 0,
  balance_due REAL DEFAULT 0, status TEXT DEFAULT 'Posted', template_version TEXT DEFAULT '',
  notes TEXT DEFAULT '', request_id TEXT UNIQUE,
  created_at TEXT DEFAULT (datetime('now','localtime')));
CREATE TABLE IF NOT EXISTS sales_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT, sales_id INTEGER NOT NULL, product_id INTEGER, unit_id INTEGER,
  barcode TEXT DEFAULT '', qty INTEGER DEFAULT 1, mrp REAL DEFAULT 0, selling_price REAL DEFAULT 0,
  discount REAL DEFAULT 0, taxable REAL DEFAULT 0, gst_rate REAL DEFAULT 5,
  cgst REAL DEFAULT 0, sgst REAL DEFAULT 0, igst REAL DEFAULT 0, amount REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS sales_payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT, sales_id INTEGER, mode TEXT NOT NULL, amount REAL NOT NULL,
  ref TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS customer_ledger (
  id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL, txn_date TEXT DEFAULT (date('now','localtime')),
  voucher TEXT DEFAULT '', invoice_no TEXT DEFAULT '', particulars TEXT DEFAULT '',
  debit REAL DEFAULT 0, credit REAL DEFAULT 0, ref_type TEXT DEFAULT '', ref_id INTEGER);
CREATE TABLE IF NOT EXISTS customer_advances (
  id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL, receipt_no TEXT UNIQUE,
  amount REAL NOT NULL, balance REAL NOT NULL, mode TEXT DEFAULT 'Cash',
  adv_date TEXT DEFAULT (date('now','localtime')), status TEXT DEFAULT 'Open',
  order_id INTEGER, notes TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS advance_adjustments (
  id INTEGER PRIMARY KEY AUTOINCREMENT, advance_id INTEGER, sales_id INTEGER,
  amount REAL NOT NULL, adj_date TEXT DEFAULT (date('now','localtime')));
CREATE TABLE IF NOT EXISTS advance_refunds (
  id INTEGER PRIMARY KEY AUTOINCREMENT, advance_id INTEGER, amount REAL NOT NULL,
  mode TEXT DEFAULT 'Cash', refund_date TEXT DEFAULT (date('now','localtime')),
  approved INTEGER DEFAULT 0, notes TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS customer_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT, order_no TEXT UNIQUE, customer_id INTEGER,
  booking_date TEXT DEFAULT (date('now','localtime')), expected_delivery TEXT DEFAULT '',
  occasion TEXT DEFAULT '', product_id INTEGER, qty INTEGER DEFAULT 1, agreed_price REAL DEFAULT 0,
  advance REAL DEFAULT 0, remaining REAL DEFAULT 0, notes TEXT DEFAULT '', status TEXT DEFAULT 'New');
CREATE TABLE IF NOT EXISTS sales_returns (
  id INTEGER PRIMARY KEY AUTOINCREMENT, sales_id INTEGER, unit_id INTEGER, product_id INTEGER,
  amount REAL DEFAULT 0, reason TEXT DEFAULT '', condition TEXT DEFAULT 'Saleable',
  refund_mode TEXT DEFAULT 'Credit', return_date TEXT DEFAULT (date('now','localtime')));
CREATE TABLE IF NOT EXISTS exchange_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT, old_sales_id INTEGER, old_unit_id INTEGER, old_amount REAL DEFAULT 0,
  new_sales_id INTEGER, new_unit_id INTEGER, new_amount REAL DEFAULT 0, difference REAL DEFAULT 0,
  difference_mode TEXT DEFAULT 'Payable', ex_date TEXT DEFAULT (date('now','localtime')));
CREATE TABLE IF NOT EXISTS credit_notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, note_no TEXT UNIQUE, sales_id INTEGER, customer_id INTEGER,
  amount REAL DEFAULT 0, reason TEXT DEFAULT '', note_date TEXT DEFAULT (date('now','localtime')));
CREATE TABLE IF NOT EXISTS expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT, exp_date TEXT DEFAULT (date('now','localtime')),
  category TEXT DEFAULT 'Miscellaneous', amount REAL NOT NULL, mode TEXT DEFAULT 'Cash',
  description TEXT DEFAULT '', attachment TEXT DEFAULT '', recurring INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS cash_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, txn_date TEXT DEFAULT (date('now','localtime')),
  txn_type TEXT NOT NULL, amount REAL NOT NULL, mode TEXT DEFAULT 'Cash',
  particulars TEXT DEFAULT '', ref_type TEXT DEFAULT '', ref_id INTEGER);
CREATE TABLE IF NOT EXISTS bank_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, account TEXT DEFAULT 'Main', txn_date TEXT DEFAULT (date('now','localtime')),
  txn_type TEXT NOT NULL, amount REAL NOT NULL, mode TEXT DEFAULT 'UPI',
  particulars TEXT DEFAULT '', ref_type TEXT DEFAULT '', ref_id INTEGER);
CREATE TABLE IF NOT EXISTS chart_of_accounts (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, acc_type TEXT);
CREATE TABLE IF NOT EXISTS journal_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT, entry_date TEXT DEFAULT (date('now','localtime')),
  voucher TEXT DEFAULT '', narration TEXT DEFAULT '', ref_type TEXT DEFAULT '', ref_id INTEGER);
CREATE TABLE IF NOT EXISTS journal_lines (
  id INTEGER PRIMARY KEY AUTOINCREMENT, entry_id INTEGER NOT NULL, account TEXT NOT NULL,
  debit REAL DEFAULT 0, credit REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS invoice_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, doc_type TEXT DEFAULT 'Sales Invoice',
  config_json TEXT DEFAULT '{}', is_default INTEGER DEFAULT 0, version INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS document_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, doc_type TEXT, config_json TEXT DEFAULT '{}');
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, record_id TEXT DEFAULT '', module TEXT, action TEXT,
  old_values TEXT DEFAULT '', new_values TEXT DEFAULT '', created_at TEXT DEFAULT (datetime('now','localtime')));
CREATE TABLE IF NOT EXISTS backup_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT, created_at TEXT DEFAULT (datetime('now','localtime')), size_bytes INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS held_bills (
  id INTEGER PRIMARY KEY AUTOINCREMENT, bill_json TEXT, created_at TEXT DEFAULT (datetime('now','localtime')));
-- Tag / label templates: one template per tag SIZE. The size drives the layout:
-- small tags show fewer fields at smaller type; large hang tags show everything.
CREATE TABLE IF NOT EXISTS label_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL,
  width_mm REAL NOT NULL, height_mm REAL NOT NULL,
  fields_json TEXT DEFAULT '[]', layout TEXT DEFAULT 'standard',
  primary_colour TEXT DEFAULT '#111111', show_border INTEGER DEFAULT 1,
  font_scale REAL DEFAULT 1.0, copies_default INTEGER DEFAULT 1, is_default INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS barcode_settings (
  id INTEGER PRIMARY KEY CHECK(id=1), prefix TEXT DEFAULT 'SR',
  default_label_template_id INTEGER, printer_type TEXT DEFAULT 'Thermal');
CREATE TABLE IF NOT EXISTS app_updates (
  id INTEGER PRIMARY KEY AUTOINCREMENT, version TEXT, status TEXT, checked_at TEXT DEFAULT (datetime('now','localtime')), notes TEXT DEFAULT '');
"""

def connect(db_path=None):
    con = sqlite3.connect(str(db_path or DB_PATH))
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con

def init_db(db_path=None):
    con = connect(db_path)
    try:
        con.executescript(SCHEMA)
        # Migrations for DBs created by v0.1.0 (CREATE TABLE IF NOT EXISTS never alters them)
        _cols = {r[1] for r in con.execute("PRAGMA table_info(company_settings)")}
        if "drive_backup_folder" not in _cols:
            con.execute("ALTER TABLE company_settings ADD COLUMN drive_backup_folder TEXT DEFAULT ''")
        if "drive_auto_backup" not in _cols:
            con.execute("ALTER TABLE company_settings ADD COLUMN drive_auto_backup INTEGER DEFAULT 0")
        con.execute("INSERT OR IGNORE INTO company_settings (id) VALUES (1)")
        # v0.2.2: point existing installs at the official GitHub update channel,
        # but ONLY if no channel was ever set — a user-chosen channel is never overwritten.
        con.execute("UPDATE company_settings SET update_channel_url='https://raw.githubusercontent.com/sbhan3967-png/saree-showroom-erp/main/version.json' WHERE id=1 AND (update_channel_url IS NULL OR update_channel_url='')")
        for name in DEFAULT_CATEGORIES:
            con.execute("INSERT OR IGNORE INTO categories (name) VALUES (?)", (name,))
        for name, typ in CHART:
            con.execute("INSERT OR IGNORE INTO chart_of_accounts (name, acc_type) VALUES (?,?)", (name, typ))
        con.execute("INSERT OR IGNORE INTO invoice_templates (name, doc_type, config_json, is_default) VALUES (?,?,?,1)",
                    ("Premium Luxury", "Sales Invoice", json.dumps({"primary": "#8a6d1b", "paper": "A4"})))
        con.execute("INSERT OR IGNORE INTO invoice_templates (name, doc_type, config_json) VALUES (?,?,?)",
                    ("Minimal", "Sales Invoice", json.dumps({"primary": "#111111", "paper": "A4"})))
        con.execute("INSERT OR IGNORE INTO invoice_templates (name, doc_type, config_json) VALUES (?,?,?)",
                    ("Compact Thermal", "Sales Invoice", json.dumps({"primary": "#000000", "paper": "80mm Thermal"})))
        # Tag sizes: fields shrink as the tag shrinks — a 25x15 tag cannot carry
        # what a 75x50 hang tag can, so each size gets its own field set.
        _labels = [
            ("Tiny Price Tag 25x15", 25, 15, '["product","selling_price","barcode"]', "compact", 0.8),
            ("Small Tag 38x25", 38, 25, '["showroom","product","selling_price","barcode"]', "compact", 0.9),
            ("Standard Saree Tag 50x30", 50, 30, '["showroom","product","sku","mrp","selling_price","barcode"]', "standard", 1.0),
            ("Saree Tag 50x25", 50, 25, '["showroom","product","selling_price","barcode"]', "standard", 1.0),
            ("Large Hang Tag 75x50", 75, 50, '["showroom","product","sku","category","colour","fabric","mrp","selling_price","barcode"]', "luxury", 1.1),
            ("Display Tag 100x60", 100, 60, '["showroom","product","sku","category","colour","fabric","design","mrp","selling_price","barcode"]', "luxury", 1.2),
        ]
        for _n, _w, _h, _f, _lay, _fs in _labels:
            con.execute("INSERT OR IGNORE INTO label_templates (name,width_mm,height_mm,fields_json,layout,font_scale) VALUES (?,?,?,?,?,?)",
                        (_n, _w, _h, _f, _lay, _fs))
        con.execute("INSERT OR IGNORE INTO barcode_settings (id) VALUES (1)")
        cur = con.execute("SELECT COUNT(*) c FROM app_meta WHERE k='schema_version'")
        if cur.fetchone()["c"] == 0:
            con.execute("INSERT INTO app_meta (k,v) VALUES ('schema_version','1')")
        con.commit()
    finally:
        con.close()

def row_to_dict(r):
    return dict(r) if r is not None else None

if __name__ == "__main__":
    init_db()
    print(f"DB ready at {DB_PATH}")

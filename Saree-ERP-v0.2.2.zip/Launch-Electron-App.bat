@echo off
REM NOTE: This is NOT an Electron build.
REM The .exe is a .NET launcher (Chrome/Edge app window + bundled Python).
REM Kept this file name only so old shortcuts still work.
cd /d "%~dp0"
call Launch-Desktop-App.bat
